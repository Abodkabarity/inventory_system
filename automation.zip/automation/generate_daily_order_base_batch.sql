CREATE OR REPLACE FUNCTION public.generate_daily_order_base_batch(p_run_date date, p_after_item_code text DEFAULT NULL::text, p_batch_size integer DEFAULT 300)
 RETURNS TABLE(processed_count integer, last_item_code text)
 LANGUAGE plpgsql
AS $function$
declare
  v_after text := coalesce(p_after_item_code,'');
  v_last_item text;
  v_count int;
begin
  -- Determine batch size & last item_code
  with items_batch as (
    select ir.item_code
    from public.item_report ir
    where lower(coalesce(ir.is_block::text,'')) not in ('true','t','1','yes','y')
      and (v_after = '' or ir.item_code > v_after)
    order by ir.item_code
    limit greatest(p_batch_size,1)
  )
  select count(*)::int, max(item_code)::text
  into v_count, v_last_item
  from items_batch;

  if coalesce(v_count,0) = 0 then
    return query select 0, null::text;
    return;
  end if;

  with
  items_batch as (
    select ir.item_code
    from public.item_report ir
    where lower(coalesce(ir.is_block::text,'')) not in ('true','t','1','yes','y')
      and (v_after = '' or ir.item_code > v_after)
    order by ir.item_code
    limit greatest(p_batch_size,1)
  ),
  b_all as (
    select br.branch_name
    from public.branches br
    where br.is_active = true
  ),
  i as (
    select
      ir.item_code,
      ir.item_name,
      ir.barcode,
      ir.category,
      ir.sub_category,
      ir.company,
      ir.supplier,
      ir.indication,
      ir.main_ingredient as active_ingredient,
      ir.pack_size_volume::text as pack_size,
      ir.concentration,
      ir.product_type as product_type_form,

      coalesce(nullif(regexp_replace(ir.retail::text, '[^0-9\.\-]', '', 'g'), ''), '0')::numeric as retail_price,
      coalesce(nullif(regexp_replace(ir.tax_percent::text, '[^0-9\.\-]', '', 'g'), ''), '0')::numeric as vat,

      case when lower(coalesce(ir.is_upp::text,'')) in ('true','t','1','yes','y') then true else false end as is_upp,

      greatest(coalesce(nullif(ir.min_order_unit, 0), 1)::numeric, 1::numeric) as moq,
      ir.store_classification as store_item_classifications,

      nullif(trim(ir.item_status::text), '') as item_purchase_type,
      nullif(trim(ir.item_priority::text), '') as sales_orientation
    from public.item_report ir
    join items_batch ib on ib.item_code = ir.item_code
  ),
sales_all_raw as (

    -- =====================================
    -- SALES LAST 45 DAYS
    -- =====================================
    select
        public._norm_text(s.branch_name) as n_branch,

        s.item_code,

        sum(
            coalesce(s.qty,0)
        )::numeric as sold_all

    from public.sales_last_45_days s

    join items_batch ib
      on ib.item_code = s.item_code

    group by 1,2

    union all

    -- =====================================
    -- TODAY LIVE SALES
    -- =====================================
    select
        public._norm_text(t.branch_name) as n_branch,

        t.item_code,

        sum(
            coalesce(t.qty,0)
        )::numeric as sold_all

    from public.stk_statement_today t

    join items_batch ib
      on ib.item_code = t.item_code

    group by 1,2
),

sales_all as (

    select

        n_branch,

        item_code,

        sum(
            sold_all
        )::numeric as sold_all

    from sales_all_raw

    group by 1,2
),
sales90 as (

    select

        public._norm_text(s.branch_name) as n_branch,

        s.item_code,

        sum(coalesce(s.cash,0))::numeric
            as total_sold_qty_cash_last_90,

        sum(coalesce(s.online,0))::numeric
            as total_sold_qty_online_last_90,

        sum(coalesce(s.insurance,0))::numeric
            as total_sold_qty_insurance_last_90,

        sum(
            coalesce(s.cash,0)
          + coalesce(s.online,0)
          + coalesce(s.insurance,0)
        )::numeric
            as total_sales_last_90_days

    from public.sales_90_days s

    join items_batch ib
      on ib.item_code = s.item_code

    group by
        public._norm_text(s.branch_name),
        s.item_code
),
  stock as (
    select public._norm_text(l.branch_name) as n_branch, l.item_code,
           max(coalesce(l.actual_qty,0))::numeric as branch_stock
    from public.stk_ledger l
    join items_batch ib on ib.item_code = l.item_code
    group by 1,2
  ),
  store_stock_cte as (
    select l.item_code, max(coalesce(l.actual_qty,0))::numeric as store_stock
    from public.stk_ledger l
    join items_batch ib on ib.item_code = l.item_code
    where public._norm_text(l.branch_name) = 'store'
    group by 1
  ),
  mismatch as (
    select public._norm_text(m.branch_name) as n_branch, m.item_code,
           max(coalesce(m.diff,0))::numeric as diff
    from public.stk_mismatch m
    join items_batch ib on ib.item_code = m.item_code
    group by 1,2
  ),
  pending as (
    select public._norm_text(t.to_warehouse) as n_branch, t.item_code,
           sum(coalesce(t.qty,0))::numeric as pending_qty
    from public.transfer t
    join items_batch ib on ib.item_code = t.item_code
    where lower(coalesce(t.status::text,'')) = 'approved'
      and lower(coalesce(t.completed::text,'')) = 'uncompleted'
    group by 1,2
  ),
  formulary as (
    select public._norm_text(f.branch_name) as n_branch, f.item_code,
           max(case when upper(coalesce(f.revised_branch_formulary::text,'')) like '%ESS%' then 'ESSENTIAL' else 'NON' end)::text as frm_type
    from public.branch_formulary f
    join items_batch ib on ib.item_code = f.item_code
    group by 1,2
  ),
  assort as (
    select distinct on (public._norm_text(a.branch_name), a.item_code)
      public._norm_text(a.branch_name) as n_branch,
      a.item_code,
      coalesce(a.assortment_qty,0)::numeric as assortment_qty,
      a.assortment_by,
      a.reason,
      a.assortment_start,
      a.assortment_end
    from public.assortment a
    join items_batch ib on ib.item_code = a.item_code
    order by public._norm_text(a.branch_name), a.item_code,
             a.assortment_end desc nulls last, a.assortment_start desc nulls last
  ),
  tma_latest as (
    select distinct on (public._norm_text(t.branch_name), t.item_code)
      public._norm_text(t.branch_name) as n_branch,
      t.item_code,
      coalesce(t.final_qty_to_keep,0)::numeric as tma_qty,
      t.start_date,
      t.end_date
    from public.tma t
    join items_batch ib on ib.item_code = t.item_code
    order by public._norm_text(t.branch_name), t.item_code,
             t.end_date desc nulls last, t.start_date desc nulls last
  ),
   last_received as (
  select
    public._norm_text(st2.branch_name) as n_branch,
    st2.item_code,
    max(st2.trans_date) as last_date
  from public.stk_statement st2
  join items_batch ib on ib.item_code = st2.item_code
  group by 1,2
),
 maxadj as (
  select distinct on (public._norm_text(ma.branch_name), ma.item_code)
    public._norm_text(ma.branch_name) as n_branch,
    ma.item_code,

    upper(coalesce(ma.adjustment_type::text,'')) as adjustment_type,  -- ✅ أضف هذا السطر

    case
      when upper(coalesce(ma.adjustment_type::text,'')) = 'DECREASE'
       and (p_run_date::date - public._parse_date_any(ma.update_date::text)) >= 45 then 0
      when upper(coalesce(ma.adjustment_type::text,'')) = 'INCREASE'
       and (p_run_date::date - public._parse_date_any(ma.update_date::text)) >= 15 then 0
      else coalesce(ma.max_adjustment_30d,0)::numeric
    end as max_adj_30d

  from public.max_adj ma
  join items_batch ib on ib.item_code = ma.item_code
  order by public._norm_text(ma.branch_name), ma.item_code,
           public._parse_date_any(ma.update_date::text) desc nulls last
),
 mrn_flag as (
  select distinct m.item_code
  from public.mrn m
  join items_batch ib on ib.item_code = m.item_code
),
  base as (
    
    select
      b.branch_name as branch,
      i.item_code,
      i.item_name,
      
case
  when greatest(
         (
           coalesce(st.branch_stock,0)
           + coalesce(mm.diff,0)
           + coalesce(pn.pending_qty,0)
         )::numeric,
         0::numeric
       ) > 0
  then coalesce(to_char(lr.last_date, 'YYYY-MM-DD'), 'More Than Month')
  else ''
end as date_of_last_qty_received_in_branch,
     case
  when mf.item_code is not null then 'Received'
  else ''
end as goods_received_last_7_days,

      greatest(
  (
    coalesce(st.branch_stock,0)
    + coalesce(mm.diff,0)
    + coalesce(pn.pending_qty,0)
  )::numeric,
  0::numeric
) as branch_stock,
      coalesce(mm.diff,0) as mismatch_stock,
      coalesce(ss.store_stock,0) as store_stock,
      coalesce(pn.pending_qty,0) as pending_stock_received,

      coalesce(st.branch_stock,0)::numeric
as effective_stock,

coalesce(mx.max_adj_30d,0) as max_adjustment_30d,
mx.adjustment_type,
coalesce(mx.adjustment_type, '') as max_type,
coalesce(
    s90.total_sold_qty_cash_last_90,
    0
) as total_sold_qty_cash_last_90,

coalesce(
    s90.total_sold_qty_online_last_90,
    0
) as total_sold_qty_online_last_90,

coalesce(
    s90.total_sold_qty_insurance_last_90,
    0
) as total_sold_qty_insurance_last_90,

coalesce(
    s90.total_sales_last_90_days,
    0
) as total_sales_last_90_days,
coalesce(
  (
    coalesce(sa.sold_all,0)::numeric
    * 30::numeric
  )
  / 45::numeric,
  0::numeric
) as qty_30_days_from_last_45d,

case

  -- 🥇 TMA أول شي (override كامل)
  when coalesce(tma.tma_qty,0) > 0 then 'TMA'

  -- 🥈 NON
  when fr.frm_type = 'NON' then 'NON'

  -- 🥉 ESSENTIAL
  when fr.frm_type = 'ESSENTIAL' then 'ESSENTIAL'

  -- NEW ITEM
  when lower(coalesce(a.reason,'')) = 'new item'
       and a.assortment_start is not null
       and a.assortment_start >= (p_run_date - interval '30 days')
    then 'NEW ITEM'

  -- SALES
  when coalesce(sa.sold_all,0) > 0 then 'SALES'

  else 'SALES'

end as branch_formulary,

      a.assortment_qty as assortment_qty_raw,
      a.assortment_by,
      a.reason,
      a.assortment_start,
      a.assortment_end,

      tma.tma_qty,
      tma.start_date as tma_start,
      tma.end_date as tma_end,

     

      i.item_purchase_type,
      i.sales_orientation,

      i.category, i.sub_category, i.company, i.supplier, i.indication,
      i.active_ingredient, i.pack_size, i.concentration, i.product_type_form,

      i.retail_price, i.vat, i.is_upp,
      i.moq as item_minimum_order_unit,
      i.barcode, i.store_item_classifications
    from b_all b
    cross join i
    left join sales_all sa on sa.n_branch = public._norm_text(b.branch_name) and sa.item_code = i.item_code
    left join stock st on st.n_branch = public._norm_text(b.branch_name) and st.item_code = i.item_code
    left join store_stock_cte ss on ss.item_code = i.item_code
    left join mismatch mm on mm.n_branch = public._norm_text(b.branch_name) and mm.item_code = i.item_code
    left join pending pn on pn.n_branch = public._norm_text(b.branch_name) and pn.item_code = i.item_code
    
    left join formulary fr on fr.n_branch = public._norm_text(b.branch_name) and fr.item_code = i.item_code
    left join assort a on a.n_branch = public._norm_text(b.branch_name) and a.item_code = i.item_code
    left join tma_latest tma on tma.n_branch = public._norm_text(b.branch_name) and tma.item_code = i.item_code
    left join maxadj mx on mx.n_branch = public._norm_text(b.branch_name) and mx.item_code = i.item_code
    left join sales90 s90
  on s90.n_branch = public._norm_text(b.branch_name)
 and s90.item_code = i.item_code
   left join last_received lr
  on lr.n_branch = public._norm_text(b.branch_name)
 and lr.item_code = i.item_code

left join mrn_flag mf
  on mf.item_code = i.item_code
  ),

  -- ✅ FIXED demand logic (same as your "correct" script)
  calc_demand as (
    select
      b.*,

      public._ceil_to_moq(
        (
          case
          
            when b.assortment_qty_raw is not null then b.assortment_qty_raw
           when lower(b.branch_formulary) = 'non' then 0
else 0
          end
        )::numeric,
        b.item_minimum_order_unit::numeric
      ) as assortment_qty_base_stock,

      (
        case
        -- ✅ NEW LOGIC (MAX ADJ OVERRIDE)
when b.adjustment_type = 'INCREASE' then
  ceil(greatest(
    coalesce(b.max_adjustment_30d,0),
    coalesce(b.tma_qty,0),
    coalesce(b.qty_30_days_from_last_45d,0),
    coalesce(b.assortment_qty_raw,0)
  ))

when b.adjustment_type = 'DECREASE' then
  ceil(greatest(
    coalesce(b.max_adjustment_30d,0),
    coalesce(b.tma_qty,0)
  ))  
          when upper(coalesce(b.branch_formulary,'')) = 'ESSENTIAL'
               and coalesce(b.tma_qty,0) <= 0
               and coalesce(b.max_adjustment_30d,0) > 0
            then ceil(coalesce(b.max_adjustment_30d,0)::numeric)

          when lower(coalesce(b.branch_formulary,'')) = 'non' then
            case
              when lower(coalesce(b.reason,'')) = 'new item'
                   and coalesce(b.tma_qty,0) <= 0
                then ceil(coalesce(public._ceil_to_moq(
                  (
                    case
                      when b.assortment_qty_raw is not null then b.assortment_qty_raw
                      when lower(b.branch_formulary) = 'non' then 0
                      else 0
                    end
                  )::numeric,
                  b.item_minimum_order_unit::numeric
                ),0)::numeric)
              when coalesce(b.tma_qty,0) <= 0
                then 0
              else ceil(greatest(
                coalesce(b.max_adjustment_30d,0)::numeric,
                coalesce(public._ceil_to_moq(
                  (
                    case
                      when b.assortment_qty_raw is not null then b.assortment_qty_raw
                      when lower(b.branch_formulary) = 'non' then 0
                      else 0
                    end
                  )::numeric,
                  b.item_minimum_order_unit::numeric
                ),0)::numeric,
                coalesce(b.qty_30_days_from_last_45d,0)::numeric,
                coalesce(b.tma_qty,0)::numeric
              ))
            end

          when coalesce(b.max_adjustment_30d,0) > 0 and coalesce(b.tma_qty,0) <= 0
            then ceil(coalesce(b.max_adjustment_30d,0)::numeric)

          when coalesce(b.max_adjustment_30d,0) = 0 and coalesce(b.tma_qty,0) <= 0
            then ceil(greatest(
              coalesce(public._ceil_to_moq(
                (
                  case
                    when b.assortment_qty_raw is not null then b.assortment_qty_raw
                    when lower(b.branch_formulary) = 'non' then 0
                    else 0
                  end
                )::numeric,
                b.item_minimum_order_unit::numeric
              ),0)::numeric,
              coalesce(b.qty_30_days_from_last_45d,0)::numeric
            ))

          else ceil(greatest(
            coalesce(b.max_adjustment_30d,0)::numeric,
            coalesce(public._ceil_to_moq(
              (
                case
                  when b.assortment_qty_raw is not null then b.assortment_qty_raw
                  when lower(b.branch_formulary) = 'non' then 0
                  else 0
                end
              )::numeric,
              b.item_minimum_order_unit::numeric
            ),0)::numeric,
            coalesce(b.qty_30_days_from_last_45d,0)::numeric,
            coalesce(b.tma_qty,0)::numeric
          ))
        end
      )::numeric as demand_for_30_days
    from base b
  ),

  -- ✅ MIN/MAX same as Excel
  calc_minmax as (
    select
      d.*,
      round(
        case
          when coalesce(d.demand_for_30_days,0) = 1 then 0
          when coalesce(d.demand_for_30_days,0) <= 25 then (coalesce(d.demand_for_30_days,0) / 30.0) * 21.0
          when coalesce(d.demand_for_30_days,0) <= 150 then (coalesce(d.demand_for_30_days,0) / 30.0) * 15.0
          else (coalesce(d.demand_for_30_days,0) / 30.0) * 10.0
        end, 0
      )::numeric as reorder_point_min,
      ceil(
        case
          when coalesce(d.demand_for_30_days,0) <= 25 then coalesce(d.demand_for_30_days,0)
          when coalesce(d.demand_for_30_days,0) <= 150 then (coalesce(d.demand_for_30_days,0) / 30.0) * 21.0
          else (coalesce(d.demand_for_30_days,0) / 30.0) * 14.0
        end
      )::numeric as reorder_max
    from calc_demand d
  ),

  -- ✅ reorder_qty TEXT + reorder_qty_num same as your "correct" script
  qty_excel as (
    select
      m.*,
case
    when upper(coalesce(m.date_of_last_qty_received_in_branch,'')) = 'MORE THAN MONTH'
    then
        case
            when floor(
                coalesce(m.branch_stock,0)
                -
                greatest(
                    coalesce(m.demand_for_30_days,0),
                    ceil(coalesce(m.qty_30_days_from_last_45d,0) * 1.5)
                )
            ) = coalesce(m.branch_stock,0)
            and floor(
                coalesce(m.branch_stock,0)
                -
                greatest(
                    coalesce(m.demand_for_30_days,0),
                    ceil(coalesce(m.qty_30_days_from_last_45d,0) * 1.5)
                )
            ) > 0
            then
                floor(
                    coalesce(m.branch_stock,0)
                    -
                    greatest(
                        coalesce(m.demand_for_30_days,0),
                        ceil(coalesce(m.qty_30_days_from_last_45d,0) * 1.5)
                    )
                ) - 1

            when floor(
                coalesce(m.branch_stock,0)
                -
                greatest(
                    coalesce(m.demand_for_30_days,0),
                    ceil(coalesce(m.qty_30_days_from_last_45d,0) * 1.5)
                )
            ) > 0
            then
                floor(
                    coalesce(m.branch_stock,0)
                    -
                    greatest(
                        coalesce(m.demand_for_30_days,0),
                        ceil(coalesce(m.qty_30_days_from_last_45d,0) * 1.5)
                    )
                )

            else null
        end
    else null
end as extra_qty_more_than_month,
      case
        when (m.reason = 'New Item' or m.tma_qty is not null) then
          case
            when (coalesce(m.demand_for_30_days,0) > 0 and coalesce(m.branch_stock,0) <= coalesce(m.reorder_point_min,0)) then
              (public._ceil_to_moq((coalesce(m.reorder_max,0) - coalesce(m.branch_stock,0))::numeric, m.item_minimum_order_unit::numeric))::text
            else ''
          end
        else
          case
            when m.branch_formulary = 'NON' then 'NON FORMULARY'
            else
              case
                when (coalesce(m.demand_for_30_days,0) > 0 and coalesce(m.branch_stock,0) <= coalesce(m.reorder_point_min,0)) then
                  (public._ceil_to_moq((coalesce(m.reorder_max,0) - coalesce(m.branch_stock,0))::numeric, m.item_minimum_order_unit::numeric))::text
                else ''
              end
          end
      end as reorder_qty,

      case
        when (coalesce(m.demand_for_30_days,0) > 0 and coalesce(m.branch_stock,0) <= coalesce(m.reorder_point_min,0)) then
          public._ceil_to_moq((coalesce(m.reorder_max,0) - coalesce(m.branch_stock,0))::numeric, m.item_minimum_order_unit::numeric)
        else 0::numeric
      end as reorder_qty_num

    from calc_minmax m
  )

  insert into public.daily_order (
    run_date, branch, item_code, item_name,
    goods_received_last_7_days, branch_stock, mismatch_stock, store_stock, pending_stock_received, effective_stock,
    max_adjustment_30d, demand_for_30_days, reorder_point_min, reorder_max,
    reorder_qty, reorder_qty_num, final_reorder_qty_store_stock_gt_0,
    date_of_last_qty_received_in_branch,
    extra_qty_more_than_month,
    total_sold_qty_cash_last_90,
total_sold_qty_online_last_90,
total_sold_qty_insurance_last_90,
total_sales_last_90_days,
    qty_30_days_from_last_45d, branch_formulary,
    assortment_qty_base_stock, assortment_by, reason, assortment_start, assortment_end,
    tma_qty, tma_start, tma_end,
    item_purchase_type, sales_orientation,
    category, sub_category, company, supplier, indication, active_ingredient, pack_size, concentration, product_type_form,
    retail_price, vat, is_upp, item_minimum_order_unit, barcode, store_item_classifications,max_type
  )
  select
    p_run_date::date, q.branch, q.item_code, q.item_name,
    q.goods_received_last_7_days, q.branch_stock, q.mismatch_stock, q.store_stock, q.pending_stock_received, q.effective_stock,
    q.max_adjustment_30d, q.demand_for_30_days, q.reorder_point_min, q.reorder_max,
    q.reorder_qty, q.reorder_qty_num, ''::text,
    q.date_of_last_qty_received_in_branch,
     q.extra_qty_more_than_month,
    q.total_sold_qty_cash_last_90,
q.total_sold_qty_online_last_90,
q.total_sold_qty_insurance_last_90,
q.total_sales_last_90_days,
    q.qty_30_days_from_last_45d, q.branch_formulary,
    q.assortment_qty_base_stock, q.assortment_by, q.reason, q.assortment_start, q.assortment_end,
    q.tma_qty, q.tma_start, q.tma_end,
   
    q.item_purchase_type, q.sales_orientation,
    q.category, q.sub_category, q.company, q.supplier, q.indication, q.active_ingredient, q.pack_size, q.concentration, q.product_type_form,
    q.retail_price, q.vat, q.is_upp, q.item_minimum_order_unit, q.barcode, q.store_item_classifications ,q.max_type
  from qty_excel q
  on conflict (run_date, branch, item_code) do update set
    item_name = excluded.item_name,
    goods_received_last_7_days = excluded.goods_received_last_7_days,
    branch_stock = excluded.branch_stock,
    mismatch_stock = excluded.mismatch_stock,
    store_stock = excluded.store_stock,
    pending_stock_received = excluded.pending_stock_received,
    effective_stock = excluded.effective_stock,
    max_adjustment_30d = excluded.max_adjustment_30d,
    demand_for_30_days = excluded.demand_for_30_days,
    reorder_point_min = excluded.reorder_point_min,
    reorder_max = excluded.reorder_max,
    reorder_qty = excluded.reorder_qty,
    reorder_qty_num = excluded.reorder_qty_num,
    date_of_last_qty_received_in_branch = excluded.date_of_last_qty_received_in_branch,
    total_sold_qty_cash_last_90 =
excluded.total_sold_qty_cash_last_90,

total_sold_qty_online_last_90 =
excluded.total_sold_qty_online_last_90,

total_sold_qty_insurance_last_90 =
excluded.total_sold_qty_insurance_last_90,

total_sales_last_90_days =
excluded.total_sales_last_90_days,
    qty_30_days_from_last_45d = excluded.qty_30_days_from_last_45d,
    branch_formulary = excluded.branch_formulary,
    assortment_qty_base_stock = excluded.assortment_qty_base_stock,
    assortment_by = excluded.assortment_by,
    reason = excluded.reason,
    assortment_start = excluded.assortment_start,
    assortment_end = excluded.assortment_end,
    tma_qty = excluded.tma_qty,
    tma_start = excluded.tma_start,
    tma_end = excluded.tma_end,
    extra_qty_more_than_month =
excluded.extra_qty_more_than_month,
    item_purchase_type = excluded.item_purchase_type,
    sales_orientation = excluded.sales_orientation,
    category = excluded.category,
    sub_category = excluded.sub_category,
    company = excluded.company,
    supplier = excluded.supplier,
    indication = excluded.indication,
    active_ingredient = excluded.active_ingredient,
    pack_size = excluded.pack_size,
    concentration = excluded.concentration,
    product_type_form = excluded.product_type_form,
    retail_price = excluded.retail_price,
    vat = excluded.vat,
    is_upp = excluded.is_upp,
    item_minimum_order_unit = excluded.item_minimum_order_unit,
    barcode = excluded.barcode,
    max_type = excluded.max_type,
    store_item_classifications = excluded.store_item_classifications;

  return query select v_count::int, v_last_item::text;
end;
$function$
