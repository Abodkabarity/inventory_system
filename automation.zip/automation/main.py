from playwright.sync_api import sync_playwright
import requests
import re
import traceback
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from datetime import datetime, timedelta

# read excel directly from memory
import pandas as pd
from io import BytesIO, StringIO

USERNAME = "a.alkabariti"
PASSWORD = "0991714051@Sa"

BASE_URL = "https://zas.proactiveerp.com"

TRANSFER_URL = "https://zas.proactiveerp.com/Inventroy/StockTransferByItemsReportPage.aspx"
STK_URL = "https://zas.proactiveerp.com/Inventroy/POSStockLadgerReport.aspx"
STK_STATEMENT_URL = (
    "https://poszas.proactiveerp.com/Pages/StockStatementReport.aspx"
)
# =========================
# SUPABASE CONFIG
# =========================
SUPABASE_URL = "https://rzvxjkbraufqbfhvftcy.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6dnhqa2JyYXVmcWJmaHZmdGN5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTI3MTIwMCwiZXhwIjoyMDg2ODQ3MjAwfQ.D1QxC_yshFdCbKPU5UmEFOM6hw3vdQRYO2_5_KatW6c"

TABLE_NAME = "stk_ledger"
TRANSFER_TABLE = "transfer"

FIRST_RUN = True  
STAGE_TIMEOUT_SECONDS = 10 * 60
# =========================
# LOGIN
# =========================



# =========================
# SESSION
# =========================
def convert_cookies_to_session(cookies):
    session = requests.Session()
    for c in cookies:
        session.cookies.set(c['name'], c['value'])
    return session


# =========================
# VIEWSTATE
# =========================
def extract_value(name, html):
    match = re.search(f'name="{name}".*?value="(.*?)"', html)
    return match.group(1) if match else ""


# =========================
# EMAIL
# =========================
import smtplib
import ssl

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


EMAIL_SENDER = "inventory.ainpharmacy@gmail.com"

# 🔥 APP PASSWORD من Google
EMAIL_PASSWORD = "nhpd iley uozd dybl"

EMAIL_RECEIVER = "inventory.ainpharmacy@gmail.com"


def send_email(subject, body):

    try:

        msg = MIMEMultipart()

        msg["From"] = EMAIL_SENDER
        msg["To"] = EMAIL_RECEIVER
        msg["Subject"] = subject

        msg.attach(
            MIMEText(body, "plain")
        )

        context = ssl.create_default_context()

        with smtplib.SMTP(
            "smtp.gmail.com",
            587
        ) as server:

            server.ehlo()

            server.starttls(
                context=context
            )

            server.ehlo()

            server.login(
                EMAIL_SENDER,
                EMAIL_PASSWORD
            )

            server.send_message(msg)

        print(
            f"📧 Email sent: {subject}"
        )

    except Exception as e:

        print(
            f"❌ Email failed: {e}"
        )
        

def execute_with_retry(
    func,
    step_name,
    max_retries=5,
    delay=15,
    send_success_email=False,
    stage_timeout=STAGE_TIMEOUT_SECONDS
):

    attempt = 1

    while attempt <= max_retries:

        try:

            print(
                f"🚀 START: {step_name} "
                f"(Attempt {attempt})"
            )

            executor = ThreadPoolExecutor(max_workers=1)
            future = executor.submit(func)

            try:
                result = future.result(timeout=stage_timeout)

            except FutureTimeoutError:
                future.cancel()
                executor.shutdown(wait=False, cancel_futures=True)
                raise TimeoutError(
                    f"{step_name} exceeded "
                    f"{stage_timeout // 60} minutes without completing."
                )

            else:
                executor.shutdown(wait=True)

            print(
                f"✅ SUCCESS: {step_name}"
            )

            # 🔥 فقط إذا طلبت
            if send_success_email:

                send_email(
                    f"SUCCESS - {step_name}",
                    f"{step_name} completed successfully."
                )

            return result

        except Exception as e:

            error_text = (
                f"❌ ERROR IN {step_name}\n\n"
                f"{str(e)}\n\n"
                f"{traceback.format_exc()}"
            )

            print(error_text)

            # 🔥 الفشل فقط
            send_email(
                f"FAILED - {step_name}",
                error_text
            )

            if isinstance(e, TimeoutError) or attempt == max_retries:

                print(
                    f"❌ FINAL FAILURE: "
                    f"{step_name}"
                )

                raise

            try:
                session.close()
            except:
                pass

            print(
                f"🔄 Retrying after "
                f"{delay} seconds..."
            )

            time.sleep(delay)

            attempt += 1


# =========================
# RPC TRUNCATE
# =========================
def run_rpc(function_name):

    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json"
    }

    res = requests.post(
        f"{SUPABASE_URL}/rest/v1/rpc/{function_name}",
        headers=headers
    )

    if res.status_code not in [200, 204]:

        raise Exception(
            f"RPC ERROR: {res.text}"
        )

    return True


# =========================
# UPLOAD STK
# =========================
def upload_stk_main_company(file_bytes):

    company_name = "APG"

    print(
        f"🚀 Uploading STK for "
        f"{company_name}"
    )

    send_email(
        "START STK UPLOAD",
        f"Starting STK upload for {company_name}"
    )

    # =========================
    # READ EXCEL
    # =========================
    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    df = df.rename(columns={
        "Branch":
            "branch_name",

        "Item Code":
            "item_code",

        "Item Name":
            "item_name",

        "Actual Qty":
            "actual_qty",
    })

    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "actual_qty"
    ]]

    # =========================
    # CLEAN
    # =========================
    df["branch_name"] = (
        df["branch_name"]
        .astype(str)
        .str.strip()
    )

    df["item_code"] = (
        df["item_code"]
        .astype(str)
        .str.strip()
    )

    df["item_name"] = (
        df["item_name"]
        .astype(str)
        .str.strip()
    )

    df["actual_qty"] = pd.to_numeric(
        df["actual_qty"],
        errors="coerce"
    ).fillna(0)

    # =========================
    # GROUP
    # =========================
    df = df.groupby(
        ["branch_name", "item_code"],
        as_index=False
    ).agg({
        "item_name":
            "first",

        "actual_qty":
            "sum"
    })

    # =========================
    # COMPANY
    # =========================
    df["company"] = company_name

    df = df.fillna("")

    data = df.to_dict(
        orient="records"
    )

    print(f"📊 Rows: {len(data)}")

    send_email(
        "STK ROWS READY",
        f"Rows prepared: {len(data)}"
    )

    # =========================
    # HEADERS
    # =========================
    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # TRUNCATE
    # =========================
    print("🧹 Clearing old APG data...")

    execute_with_retry(
        lambda: run_rpc(
            "truncate_stk_ledger"
        ),
        step_name="TRUNCATE_STK_LEDGER"
    )

    print("✅ Old data deleted")

    send_email(
        "STK TABLE CLEARED",
        "Old STK APG data deleted successfully"
    )

    # =========================
    # INSERT
    # =========================
    print("⬆️ Inserting new data...")

    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/stk_ledger",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"STK_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} inserted"
        )

  

    print("🎉 STK upload completed")

    send_email(
        "STK UPLOAD COMPLETED",
        "All STK batches uploaded successfully."
    )


# =========================
# UPLOAD TRANSFER
# =========================
def upload_transfer_to_supabase(file_bytes):

    print("🚀 Uploading TRANSFER to Supabase...")

    send_email(
        "START TRANSFER UPLOAD",
        "Transfer upload started."
    )

    try:

        df = pd.read_csv(
            BytesIO(file_bytes),
            encoding="utf-8"
        )

    except:

        df = pd.read_csv(
            BytesIO(file_bytes),
            encoding="latin1"
        )

    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    df = df.rename(columns={
        "from warhouse":
            "from_warehouse",

        "to warhouse":
            "to_warehouse",

        "transfer date":
            "transfer_date",

        "transfer type": 
            "transfer_type",

        "status":
            "status",

        "item code":
            "item_code",

        "item name":
            "item_name",

        "qty":
            "qty",

        "completed":
            "completed"
    })

    df["transfer_date"] = pd.to_datetime(
        df["transfer_date"],
        dayfirst=True,
        errors="coerce"
    ).dt.strftime("%Y-%m-%d")

    df["qty"] = (
        df["qty"]
        .astype(str)
        .str.replace(",", "")
        .astype(float)
    )

    df = df[[
        "from_warehouse",
        "to_warehouse",
        "transfer_date",
        "transfer_type",
        "status",
        "item_code",
        "item_name",
        "qty",
        "completed"
    ]]

    df = df.fillna(0)
    df["transfer_type"] = (
        df["transfer_type"]
        .astype(str)
        .str.strip()
    )
    data = df.to_dict(
        orient="records"
    )

    print(f"📊 Rows: {len(data)}")

    send_email(
        "TRANSFER ROWS READY",
        f"Rows count: {len(data)}"
    )

    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # TRUNCATE
    # =========================
    print("🧹 Clearing TRANSFER table...")

    execute_with_retry(
        lambda: run_rpc(
            "truncate_transfer"
        ),
        step_name="TRUNCATE_TRANSFER"
    )

    print("✅ TRANSFER cleared")

    send_email(
        "TRANSFER CLEARED",
        "Transfer table cleared successfully."
    )

    # =========================
    # INSERT
    # =========================
    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/{TRANSFER_TABLE}",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"TRANSFER_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} done"
        )

   

    print("🎉 TRANSFER upload completed")

    send_email(
        "TRANSFER COMPLETED",
        "Transfer upload completed successfully."
    )
   # =========================
# 🔥 Upload Sales Report
# =========================
def upload_sales_to_supabase(
    file_bytes,
    allow_delete=True
):

    global FIRST_RUN

    print("🚀 Uploading SALES to Supabase...")

    send_email(
        "START SALES UPLOAD",
        "Sales upload started."
    )

    # =========================
    # READ FILE SAFE
    # =========================
    try:

        # 🔥 إذا رجع HTML بدل Excel
        if b"<html" in file_bytes[:500].lower():

            raise Exception(
                "Received HTML instead of Excel file"
            )

        # 🔥 XLSX
        if file_bytes[:2] == b"PK":

            df = pd.read_excel(
                BytesIO(file_bytes),
                engine="openpyxl"
            )

        # 🔥 XLS
        else:

            df = pd.read_excel(
                BytesIO(file_bytes),
                engine="xlrd"
            )

    except Exception as e:

        raise Exception(
            f"Failed reading SALES Excel file: {str(e)}"
        )

    # =========================
    # CLEAN COLUMNS
    # =========================
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    print(
        "Columns:",
        df.columns.tolist()
    )

    send_email(
        "SALES FILE READ",
        f"Columns:\n{df.columns.tolist()}"
    )

    # =========================
    # RENAME
    # =========================
    df = df.rename(columns={
    "branch":
        "branch_name",

    "itemcode":
        "item_code",

    "itemname":
        "item_name",

    "qty":
        "qty",

    "invdate":
        "inv_date"
})

    required = [
    "branch_name",
    "item_code",
    "item_name",
    "qty",
    "inv_date"
]

    for col in required:

        if col not in df.columns:

            error_msg = (
                f"❌ Missing column: {col}"
            )

            print(error_msg)

            send_email(
                "SALES ERROR",
                error_msg
            )

            return

    # =========================
    # CLEAN QTY
    # =========================
    df["qty"] = (
        df["qty"]
        .astype(str)
        .str.replace(",", "", regex=False)
    )

    df["qty"] = pd.to_numeric(
        df["qty"],
        errors="coerce"
    ).fillna(0)

    df["inv_date"] = pd.to_datetime(
        df["inv_date"],
        dayfirst=True,
        errors="coerce"
    ).dt.strftime("%Y-%m-%d")

    print(
        "NULL INV DATE =",
        df["inv_date"].isna().sum()
    )

    # =========================
    # FILL NULLS
    # =========================
    df = df.fillna({
        "branch_name": "UNKNOWN",
        "item_code": "UNKNOWN",
        "item_name": "UNKNOWN"
    })

    # =========================
    # CLEAN TEXT
    # =========================
    df["branch_name"] = (
        df["branch_name"]
        .astype(str)
        .str.strip()
    )

    df["item_code"] = (
        df["item_code"]
        .astype(str)
        .str.strip()
    )

    df["item_name"] = (
        df["item_name"]
        .astype(str)
        .str.strip()
    )
    df = df[
        [
            "branch_name",
            "item_code",
            "item_name",
            "qty",
            "inv_date"
        ]
    ]
# =========================
# GROUP SAME ITEM SAME DAY
# =========================
    df = df.groupby(
        [
            "branch_name",
            "item_code",
            "inv_date"
        ],
        as_index=False
    ).agg({
        "item_name": "first",
        "qty": "sum"
    })
    print("Rows:", len(df))

    print(
        "Total qty:",
        df["qty"].sum()
    )

    # =========================
    # NAN CHECK
    # =========================
    print("\n========== NAN CHECK ==========")

    for col in df.columns:

        count = df[col].isna().sum()

        if count > 0:

            print(
                f"{col} => {count}"
            )

    print("==============================")

    bad_rows = df[
        df.isna().any(axis=1)
    ]

    print(
        "BAD ROWS =",
        len(bad_rows)
    )

    if len(bad_rows) > 0:

        print(
            bad_rows.head(20)
            .to_string()
        )

    send_email(
        "SALES CLEANED",
        f"Rows: {len(df)}\n"
        f"Total Qty: {df['qty'].sum()}"
    )

    # =========================
    # TO JSON
    # =========================

    data = df.to_dict(
        orient="records"
    )
    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # FIRST RUN CLEAR
    # =========================
    if FIRST_RUN and allow_delete:

        print(
            "🧹 FIRST RUN → "
            "clearing old data..."
        )

        execute_with_retry(
            lambda: run_rpc(
                "truncate_sales_last_45_days"
            ),
            step_name=
                "TRUNCATE_SALES"
        )

        FIRST_RUN = False

        print("✅ Old data cleared")

        send_email(
            "SALES TABLE CLEARED",
            "Old sales table deleted successfully."
        )

    # =========================
    # INSERT
    # =========================
    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/rpc/upsert_sales",
                json={
                    "p_data": batch
                },
                headers=headers
            )

            if res.status_code not in [200, 201, 204]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"SALES_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} done"
        )

    print(
        "🎉 SALES uploaded successfully"
    )

    send_email(
        "SALES COMPLETED",
        "Sales upload completed successfully."
    )


# =========================
# ITEM REPORT
# =========================
def upload_item_report_to_supabase(
    file_bytes
):

    print(
        "🚀 Uploading ITEM REPORT "
        "to Supabase..."
    )

    send_email(
        "START ITEM REPORT",
        "Item report upload started."
    )

    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    # تنظيف أسماء الأعمدة
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    print(
        "Columns from file:",
        df.columns.tolist()
    )

    send_email(
        "ITEM REPORT COLUMNS",
        str(df.columns.tolist())
    )

    # =========================
    # SAFE RENAME
    # =========================
    rename_map = {
        "item code":
            "item_code",

        "barcode":
            "barcode",

        "item name":
            "item_name",

        "status":
            "status",

        "retail":
            "retail",

        "unit type":
            "unit_type",

        "item status":
            "item_status",

        "item priority":
            "item_priority",

        "pack size volume":
            "pack_size_volume",

        "concentration":
            "concentration",

        "haad code":
            "haad_code",

        "category 1 name":
            "category",

        "category 2 name":
            "sub_category",

        "category 3 name":
            "supplier",

        "category 4 name":
            "company",

        "category 5 name":
            "brand",

        "category 6 name":
            "indication",

        "category 7 name":
            "main_ingredient",

        "category 8 name":
            "product_type",

        "isblock":
            "is_block",

        "is upp":
            "is_upp",

        "minimum order unit":
            "min_order_unit",

        "store classification":
            "store_classification",

        "tax %":
            "tax_percent",

        "insurance tier":
            "insurance_tier"
    }

    df = df.rename(
        columns=rename_map
    )

    # =========================
    # KEEP ONLY EXISTING COLUMNS
    # =========================
    required_columns = list(
        rename_map.values()
    )

    existing_columns = [
        col
        for col in required_columns
        if col in df.columns
    ]

    df = df[existing_columns]

    print(
        "Final columns:",
        df.columns.tolist()
    )

    # =========================
    # CLEAN
    # =========================
    df = df.fillna("")

    if "status" in df.columns:

        df["status"] = (
            df["status"]
            .astype(str)
            .str.strip()
            .str.lower()
        )

    if "item_status" in df.columns:

        df["item_status"] = (
            df["item_status"]
            .astype(str)
            .str.strip()
        )

    if "is_block" in df.columns:

        df["is_block"] = (
            df["is_block"]
            .astype(str)
            .str.strip()
            .str.lower()
        )

    # =========================
    # FILTER
    # =========================
    if all(
        col in df.columns
        for col in [
            "status",
            "item_status",
            "is_block"
        ]
    ):

        df = df[
            (
                df["status"]
                == "active"
            ) &
            (
                df["item_status"]
                .str.startswith(("1", "2"))
            ) &
            (
                df["is_block"]
                .isin([
                    "unchecked",
                    "false",
                    "0",
                    "no"
                ])
            )
        ]

    print(
        f"✅ After filter rows: "
        f"{len(df)}"
    )

    send_email(
        "ITEM REPORT FILTERED",
        f"Rows after filter: {len(df)}"
    )

    # =========================
    # REMOVE DUPLICATES
    # =========================
    before = len(df)

    df = df.drop_duplicates()

    after = len(df)

    print(
        f"🧹 Removed duplicates: "
        f"{before - after}"
    )

    # =========================
    # CONVERT
    # =========================
    data = df.to_dict(
        orient="records"
    )

    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # TRUNCATE TABLE
    # =========================
    print("🧹 Clearing table...")

    execute_with_retry(
        lambda: run_rpc(
            "truncate_item_report"
        ),
        step_name=
            "TRUNCATE_ITEM_REPORT"
    )

    print("✅ Table cleared")

    send_email(
        "ITEM REPORT CLEARED",
        "item_report table cleared."
    )

    # =========================
    # INSERT
    # =========================
    batch_size = 2000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/item_report",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"ITEM_REPORT_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} inserted"
        )

    

    print(
        "🎉 ITEM REPORT uploaded "
        "successfully"
    )

    send_email(
        "ITEM REPORT COMPLETED",
        "Item report uploaded successfully."
    )
# =========================
# TRANSFER
# =========================
def download_transfer(session):

    print("📦 TRANSFER REPORT")

    send_email(
        "TRANSFER STARTED",
        "Transfer report download started."
    )

    today = datetime.today()

    from_date = (
        today - timedelta(days=30)
    ).strftime("%Y-%m-%d")

    to_date = today.strftime("%Y-%m-%d")

    print(f"📅 {from_date} → {to_date}")

    def open_transfer_page():

        res = session.get(
            TRANSFER_URL
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening transfer page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_transfer_page,
        step_name="OPEN_TRANSFER_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    viewstategenerator = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # 🔥 PREVIEW
    # =========================
    payload_preview = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            viewstategenerator,

        "__EVENTTARGET":
            "",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "__ASYNCPOST":
            "true",

        "ctl00$ScriptManager1":
            "ctl00$ContentPlaceHolder1$UP|ctl00$ContentPlaceHolder1$btnPreview",

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$ddlStockTransferType":
            "0",

        "ctl00$ContentPlaceHolder1$ddlTransferStatus":
            "0",

        "ctl00$ContentPlaceHolder1$ddlTransferCompleted":
            "0",

        "ctl00$ContentPlaceHolder1$btnPreview":
            "Preview"
    }

    headers_ajax = {
        "Content-Type":
            "application/x-www-form-urlencoded; charset=UTF-8",

        "X-MicrosoftAjax":
            "Delta=true",

        "X-Requested-With":
            "XMLHttpRequest",

        "Referer":
            TRANSFER_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("📊 Running Preview...")

    def preview_transfer():

        res = session.post(
            TRANSFER_URL,
            data=payload_preview,
            headers=headers_ajax
        )

        if res.status_code != 200:

            raise Exception(
                f"Transfer preview failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        preview_transfer,
        step_name="TRANSFER_PREVIEW"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # 🔥 EXPORT
    # =========================
    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            viewstategenerator,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnCsvExport",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$ddlStockTransferType":
            "0",

        "ctl00$ContentPlaceHolder1$ddlTransferStatus":
            "0",

        "ctl00$ContentPlaceHolder1$ddlTransferCompleted":
            "0",
    }

    headers_normal = {
        "Content-Type":
            "application/x-www-form-urlencoded",

        "Referer":
            TRANSFER_URL,

        "User-Agent":
            "Mozilla/5.0"
    }
    print("📥 Downloading transfer...")

    def export_transfer():

        session.headers.update({
            "Connection": "close"
        })

        res = session.post(
            TRANSFER_URL,
            data=payload_export,
            headers=headers_normal,
            timeout=300
        )

        if b"html" in res.content[:300].lower():

            raise Exception(
                "Transfer export failed, received HTML"
            )

        if len(res.content) < 1000:

            raise Exception(
                "Transfer file is too small."
            )

        return res

    res = execute_with_retry(
        export_transfer,
        step_name="TRANSFER_EXPORT"
    )



    print("✅ transfer.csv saved")

    send_email(
        "TRANSFER DOWNLOADED",
        "transfer.csv downloaded successfully."
    )

    upload_transfer_to_supabase(
        res.content
    )

    send_email(
        "TRANSFER COMPLETED",
        "Transfer upload completed successfully."
    )


# =========================
# STK
# =========================
def download_stk(session):

    print("📦 STK")

    send_email(
        "STK STARTED",
        "STK report started."
    )

    today = datetime.today().strftime(
        "%Y-%m-%d"
    )

    def open_stk_page():

        res = session.get(STK_URL)

        if res.status_code != 200:

            raise Exception(
                f"Failed opening STK page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_stk_page,
        step_name="OPEN_STK_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            today,

        "ctl00$ContentPlaceHolder1$DatToDate":
            today,

        "ctl00$ContentPlaceHolder1$ddlBranch":
            "0",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    def refresh_stk():

        res = session.post(
            STK_URL,
            data=payload_refresh
        )

        if res.status_code != 200:

            raise Exception(
                f"STK refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_stk,
        step_name="STK_REFRESH"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading STK...")

    def export_stk():

        res = session.post(
            STK_URL,
            data=payload_export
        )

        if len(res.content) < 1000:

            raise Exception(
                "STK export failed."
            )

        return res

    res = execute_with_retry(
        export_stk,
        step_name="STK_EXPORT"
    )

    print("✅ STK ready")

    send_email(
        "STK DOWNLOADED",
        "STK file downloaded successfully."
    )

    upload_stk_main_company(
        res.content
    )

    send_email(
        "STK COMPLETED",
        "STK upload completed successfully."
    )


# =========================
# 📦 SALES RANGE
# =========================
def download_sales_range(
    session,
    from_date,
    to_date,
    filename
):

    SALES_URL = (
        "https://zas.proactiveerp.com/"
        "Sales/POSSalesByItemReport.aspx"
    )

    print(f"📅 {from_date} → {to_date}")

    send_email(
        "SALES RANGE STARTED",
        f"{from_date} → {to_date}"
    )

    def open_sales_page():

        res = session.get(
            SALES_URL
        )

        if res.status_code != 200:

            raise Exception(
                f"Sales page failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_sales_page,
        step_name="OPEN_SALES_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "__ASYNCPOST":
            "true",

        "ctl00$ScriptManager1":
            "ctl00$ContentPlaceHolder1$UP|ctl00$ContentPlaceHolder1$bntGVRefresh",

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    headers_ajax = {
        "Content-Type":
            "application/x-www-form-urlencoded; charset=UTF-8",

        "X-MicrosoftAjax":
            "Delta=true",

        "X-Requested-With":
            "XMLHttpRequest",

        "Referer":
            SALES_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("📊 Refresh...")

    def refresh_sales():

        res = session.post(
            SALES_URL,
            data=payload_refresh,
            headers=headers_ajax
        )

        if res.status_code != 200:

            raise Exception(
                f"Sales refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_sales,
        step_name="SALES_REFRESH"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$ctl00",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "ctl00$ContentPlaceHolder1$ctl00":
            "Export",

        "ctl00$ContentPlaceHolder1$ctl00$DX$State":
            '{"exportType":"Xlsx"}',

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,
    }

    headers_normal = {
        "Content-Type":
            "application/x-www-form-urlencoded",

        "Referer":
            SALES_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print(f"📥 Downloading {filename}...")

    def export_sales():

        res = session.post(
            SALES_URL,
            data=payload_export,
            headers=headers_normal
        )

        # 🔥 CHECK HTML
        if b"html" in res.content[:300].lower():

            raise Exception(
                "Sales export failed, received HTML"
            )

        if len(res.content) < 1000:

            raise Exception(
                "Sales file empty."
            )

        return res
    res = execute_with_retry(
        export_sales,
        step_name="SALES_EXPORT"
    )



    print("✅ File ready → uploading...")

    send_email(
        "SALES FILE DOWNLOADED",
        filename
    )

    upload_sales_to_supabase(
        res.content
    )

    send_email(
        "SALES RANGE COMPLETED",
        f"{filename} uploaded successfully."
    )

# =========================
# 📦 SALES 45D (SPLIT 🔥🔥)
# =========================
def download_sales_45d(session):

    print("📦 SALES 45D SPLIT")

    send_email(
        "SALES 45D STARTED",
        "Sales 45D split started."
    )

    today = datetime.today()

    yesterday = today - timedelta(days=1)

    full_from = yesterday - timedelta(days=43)

    full_to = yesterday

    # 🔥 تقسيم
    mid = full_from + timedelta(days=22)

    part1_from = full_from.strftime("%Y-%m-%d")

    part1_to = mid.strftime("%Y-%m-%d")

    part2_from = (
        mid + timedelta(days=1)
    ).strftime("%Y-%m-%d")

    part2_to = full_to.strftime("%Y-%m-%d")

    print("🔹 PART 1")

    send_email(
        "SALES PART 1",
        f"{part1_from} → {part1_to}"
    )

    execute_with_retry(
        lambda: download_sales_range(
            session,
            part1_from,
            part1_to,
            "sales_45d_part1.xlsx"
        ),
        step_name="SALES_45D_PART_1"
    )

    print("🔹 PART 2")

    send_email(
        "SALES PART 2",
        f"{part2_from} → {part2_to}"
    )

    execute_with_retry(
        lambda: download_sales_range(
            session,
            part2_from,
            part2_to,
            "sales_45d_part2.xlsx"
        ),
        step_name="SALES_45D_PART_2"
    )

    send_email(
        "SALES 45D COMPLETED",
        "Sales 45D completed successfully."
    )


# =========================
# Item Report Download
# =========================
def download_item_report(session):

    print("📦 ITEM REPORT")

    send_email(
        "ITEM REPORT STARTED",
        "Item report download started."
    )

    ITEM_URL = (
        "https://zas.proactiveerp.com/"
        "Inventroy/ItemReport.aspx"
    )

    def open_item_page():

        res = session.get(
            ITEM_URL
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening item report: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_item_page,
        step_name="OPEN_ITEM_REPORT_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # PREVIEW
    # =========================
    payload_preview = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "__ASYNCPOST":
            "true",

        "ctl00$ScriptManager1":
            "ctl00$ContentPlaceHolder1$UP|ctl00$ContentPlaceHolder1$btnPreview",

        "ctl00$ContentPlaceHolder1$btnPreview":
            "Preview"
    }

    headers_ajax = {
        "Content-Type":
            "application/x-www-form-urlencoded; charset=UTF-8",

        "X-MicrosoftAjax":
            "Delta=true",

        "X-Requested-With":
            "XMLHttpRequest",

        "Referer":
            ITEM_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("📊 Running Preview...")

    def preview_item_report():

        res = session.post(
            ITEM_URL,
            data=payload_preview,
            headers=headers_ajax
        )

        if res.status_code != 200:

            raise Exception(
                f"Item preview failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        preview_item_report,
        step_name="ITEM_REPORT_PREVIEW"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # EXPORT
    # =========================
    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    headers_normal = {
        "Content-Type":
            "application/x-www-form-urlencoded",

        "Referer":
            ITEM_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("📥 Downloading ITEM REPORT...")

    def export_item_report():

        res = session.post(
            ITEM_URL,
            data=payload_export,
            headers=headers_normal
        )

        if len(res.content) < 1000:

            raise Exception(
                "Item report file empty."
            )

        return res

    res = execute_with_retry(
        export_item_report,
        step_name="ITEM_REPORT_EXPORT"
    )



    print("✅ File ready → uploading...")

    send_email(
        "ITEM REPORT DOWNLOADED",
        "item_report.xlsx downloaded successfully."
    )

    upload_item_report_to_supabase(
        res.content
    )

    send_email(
        "ITEM REPORT COMPLETED",
        "Item report uploaded successfully."
    )


# =========================
# 📦 MATERIAL RECEIPT NOTE
# =========================
def download_material_receipt(session):

    print("📦 MATERIAL RECEIPT REPORT")

    send_email(
        "MRN STARTED",
        "Material Receipt Note started."
    )

    MRN_URL = (
        "https://zas.proactiveerp.com/"
        "Purchase/MaterialReceiptNoteReport.aspx"
    )

    today = datetime.today()

    from_date = (
        today - timedelta(days=6)
    ).strftime("%Y-%m-%d")

    to_date = (
        today + timedelta(days=1)
    ).strftime("%Y-%m-%d")

    print(
        f"📅 Date range: "
        f"{from_date} -> {to_date}"
    )

    def open_mrn_page():

        res = session.get(
            MRN_URL,
            timeout=300

        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening MRN page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_mrn_page,
        step_name="OPEN_MRN_PAGE",
        max_retries=1

    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "__ASYNCPOST":
            "true",

        "ctl00$ScriptManager1":
            "ctl00$ContentPlaceHolder1$UP|ctl00$ContentPlaceHolder1$bntGVRefresh",

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    headers_ajax = {
        "Content-Type":
            "application/x-www-form-urlencoded; charset=UTF-8",

        "X-MicrosoftAjax":
            "Delta=true",

        "X-Requested-With":
            "XMLHttpRequest",

        "Referer":
            MRN_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("🔄 Refreshing report...")

    def refresh_mrn():

        res = session.post(
            MRN_URL,
            data=payload_refresh,
            headers=headers_ajax,
            timeout=300

        )

        if res.status_code != 200:

            raise Exception(
                f"MRN refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_mrn,
        step_name="MRN_REFRESH",
        max_retries=1

    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$GridSetting$btnXlsxExport",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "__ASYNCPOST":
            "true",

        "ctl00$ScriptManager1":
            "ctl00$ContentPlaceHolder1$UP|ctl00$ContentPlaceHolder1$GridSetting$btnXlsxExport",

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,
    }

    print("📥 Downloading Excel...")

    def export_mrn():

        res = session.post(
            MRN_URL,
            data=payload_export,
            headers=headers_ajax,
            timeout=300

        )

        if (
            b"html"
            in res.content[:200].lower()
        ):

            raise Exception(
                "Export failed, received HTML"
            )

        if len(res.content) < 1000:

            raise Exception(
                "MRN file too small"
            )

        return res

    res = execute_with_retry(
        export_mrn,
        step_name="MRN_EXPORT",
        max_retries=1

    )

    print("✅ Processing Excel...")

    df = pd.read_excel(
        BytesIO(res.content)
    )

    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    df = df.rename(columns={
        "warehouse":
            "warehouse",

        "status":
            "status",

        "item code":
            "item_code",

        "item name":
            "item_name"
    })

    required = [
        "warehouse",
        "status",
        "item_code",
        "item_name"
    ]

    for col in required:

        if col not in df.columns:

            error_msg = (
                f"Missing column: {col}"
            )

            print(error_msg)

            send_email(
                "MRN ERROR",
                error_msg
            )

            return

    df["warehouse"] = (
        df["warehouse"]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    df["status"] = (
        df["status"]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    allowed_warehouses = [
        "store",
        "main virtual",
        "new virtual"
    ]

    df = df[
        (
            df["warehouse"]
            .isin(allowed_warehouses)
        ) &
        (
            df["status"]
            == "approved"
        )
    ]

    df = df[[
        "warehouse",
        "status",
        "item_code",
        "item_name"
    ]]

    df = df.fillna("")

    data = df.to_dict(
        orient="records"
    )

    print(
        f"📊 Filtered rows: "
        f"{len(data)}"
    )

    send_email(
        "MRN FILTERED",
        f"Filtered rows: {len(data)}"
    )

    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    print("🧹 Clearing MRN table...")

    execute_with_retry(
        lambda: run_rpc(
            "truncate_mrn"
        ),
        step_name="TRUNCATE_MRN"
    )

    print("✅ MRN table cleared")

    send_email(
        "MRN TABLE CLEARED",
        "MRN table truncated successfully."
    )

    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res_up = requests.post(
                f"{SUPABASE_URL}/rest/v1/mrn",
                json=batch,
                headers=headers
            )

            if res_up.status_code not in [200, 201]:

                raise Exception(
                    res_up.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"MRN_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} done"
        )

     

    print("🎉 MRN upload completed")

    send_email(
        "MRN COMPLETED",
        "MRN upload completed successfully."
    )
# =========================
# 📦 71 Branch
# =========================
def get_session_cookies(company_name=None):

    send_email(
        "LOGIN STARTED",
        f"Starting login for company: {company_name}"
    )

    with sync_playwright() as p:

        browser = p.chromium.launch(
            headless=True
        )

        context = browser.new_context()

        page = context.new_page()

        print("🔐 Logging in...")

        page.goto(BASE_URL)

        page.fill(
            "#txtUserName",
            USERNAME
        )

        page.fill(
            "#txtPassword",
            PASSWORD
        )

        page.click("#btnLogin")

        # 👇 ننتظر dropdown بدل الزر مباشرة
        page.wait_for_selector("select")

        # 👇 إذا أعطيت اسم شركة → اختارها
        if company_name:

            print(
                f"Selecting company: "
                f"{company_name}"
            )

            send_email(
                "SELECTING COMPANY",
                f"{company_name}"
            )

            page.select_option(
                "select",
                label=company_name
            )

        # 👇 بعدها اضغط زر الدخول
        page.click("#btnSelectCompany")

        page.wait_for_load_state(
            "networkidle"
        )

        cookies = context.cookies()

        browser.close()

        print("✅ Session ready")

        send_email(
            "LOGIN SUCCESS",
            f"Session ready for: {company_name}"
        )

        return cookies


# =========================
# 📦 71 Branch STK Ledger
# =========================
def download_stk_71():

    print("📦 STK - 71 Pharmacy")

    send_email(
        "71 STK STARTED",
        "71 Pharmacy STK started."
    )

    # 👇 دخول على الشركة الثانية
    cookies = execute_with_retry(
        lambda: get_session_cookies(
            "71 Pharmacy L.L.C."
        ),
        step_name="LOGIN_71_STK"
    )

    session = convert_cookies_to_session(
        cookies
    )

    today = datetime.today().strftime(
        "%Y-%m-%d"
    )

    def open_stk_page():

        res = session.get(STK_URL)

        if res.status_code != 200:

            raise Exception(
                f"Failed opening STK page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_stk_page,
        step_name="OPEN_71_STK_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            today,

        "ctl00$ContentPlaceHolder1$DatToDate":
            today,

        "ctl00$ContentPlaceHolder1$ddlBranch":
            "0",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    print("🔄 Refreshing STK...")

    def refresh_stk():

        res = session.post(
            STK_URL,
            data=payload_refresh
        )

        if res.status_code != 200:

            raise Exception(
                f"STK refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_stk,
        step_name="REFRESH_71_STK"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading STK...")

    def export_stk():

        res = session.post(
            STK_URL,
            data=payload_export
        )

        if len(res.content) < 1000:

            raise Exception(
                "71 STK export failed."
            )

        return res

    res = execute_with_retry(
        export_stk,
        step_name="EXPORT_71_STK"
    )

    filename = (
        f"stk_ledger_71_"
        f"{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    )



    send_email(
        "71 STK DOWNLOADED",
        filename
    )

    upload_stk_filtered(
        res.content,
        "71 Pharmacy L.L.C."
    )

    send_email(
        "71 STK COMPLETED",
        "71 STK uploaded successfully."
    )


# =========================
# 🔥 Upload STK 71
# =========================
def upload_stk_filtered(
    file_bytes,
    company_name
):

    print(
        f"🚀 Uploading STK for "
        f"{company_name}"
    )

    send_email(
        "71 STK UPLOAD STARTED",
        company_name
    )

    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    df = df.rename(columns={
        "Branch":
            "branch_name",

        "Item Code":
            "item_code",

        "Item Name":
            "item_name",

        "Actual Qty":
            "actual_qty",
    })

    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "actual_qty"
    ]]

    allowed_branches = [
        "Zakher Branch",
        "Asharej Branch",
        "Ayla Branch"
    ]

    df = df[
        df["branch_name"]
        .isin(allowed_branches)
    ]

    # 🔥 أضف الشركة
    df["company"] = company_name

    df["branch_name"] = (
        df["branch_name"]
        .astype(str)
        .str.strip()
    )

    df["item_code"] = (
        df["item_code"]
        .astype(str)
        .str.strip()
    )

    df["item_name"] = (
        df["item_name"]
        .astype(str)
        .str.strip()
    )

    df["actual_qty"] = pd.to_numeric(
        df["actual_qty"],
        errors="coerce"
    ).fillna(0)

    df = df.groupby(
        [
            "branch_name",
            "item_code"
        ],
        as_index=False
    ).agg({
        "item_name":
            "first",

        "actual_qty":
            "sum",

        "company":
            "first"
    })

    df = df.fillna("")

    data = df.to_dict(
        orient="records"
    )

    print(
        f"📊 Rows after filter: "
        f"{len(data)}"
    )

    send_email(
        "71 STK FILTERED",
        f"Rows: {len(data)}"
    )

    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # DELETE OLD DATA
    # =========================
    print("🧹 Clearing old 71 data...")

    execute_with_retry(
        lambda: requests.delete(
            f"{SUPABASE_URL}/rest/v1/stk_ledger?"
            f"company=eq.{company_name}",
            headers=headers
        ),
        step_name="DELETE_71_STK"
    )

    print("✅ Old 71 data deleted")

    send_email(
        "71 STK CLEARED",
        "Old 71 STK deleted."
    )

    # =========================
    # INSERT
    # =========================
    batch_size = 2000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def insert_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/stk_ledger",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            insert_batch,
            step_name=
                f"INSERT_71_STK_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} inserted"
        )

       

    print("🎉 Done without affecting other companies")

    send_email(
        "71 STK FINISHED",
        "71 STK upload completed."
    )


# =========================
# 71 Sales
# =========================
def download_sales_71():

    print("📦 SALES - 71 Pharmacy (FULL)")

    send_email(
        "71 SALES STARTED",
        "71 sales download started."
    )

    # 👇 دخول على الشركة 71
    cookies = execute_with_retry(
        lambda: get_session_cookies(
            "71 Pharmacy L.L.C."
        ),
        step_name="LOGIN_71_SALES"
    )

    session = convert_cookies_to_session(
        cookies
    )

    SALES_URL = (
        "https://zas.proactiveerp.com/"
        "Sales/POSSalesByItemReport.aspx"
    )

    today = datetime.today()

    yesterday = (
        today - timedelta(days=1)
    )

    from_date = (
        yesterday - timedelta(days=44)
    ).strftime("%Y-%m-%d")

    to_date = yesterday.strftime(
        "%Y-%m-%d"
    )

    print(
        f"📅 71 → "
        f"{from_date} → {to_date}"
    )

    def open_sales_page():

        res = session.get(
            SALES_URL
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening sales page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_sales_page,
        step_name="OPEN_71_SALES_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # REFRESH
    # =========================
    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "__ASYNCPOST":
            "true",

        "ctl00$ScriptManager1":
            "ctl00$ContentPlaceHolder1$UP|ctl00$ContentPlaceHolder1$bntGVRefresh",

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    headers_ajax = {
        "Content-Type":
            "application/x-www-form-urlencoded; charset=UTF-8",

        "X-MicrosoftAjax":
            "Delta=true",

        "X-Requested-With":
            "XMLHttpRequest",

        "Referer":
            SALES_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("📊 Refresh 71...")

    def refresh_sales():

        res = session.post(
            SALES_URL,
            data=payload_refresh,
            headers=headers_ajax
        )

        if res.status_code != 200:

            raise Exception(
                f"71 sales refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_sales,
        step_name="REFRESH_71_SALES"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # EXPORT
    # =========================
    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$ctl00",

        "__EVENTARGUMENT":
            "",

        "__LASTFOCUS":
            "",

        "ctl00$ContentPlaceHolder1$ctl00":
            "Export",

        "ctl00$ContentPlaceHolder1$ctl00$DX$State":
            '{"exportType":"Xlsx"}',

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,
    }

    headers_normal = {
        "Content-Type":
            "application/x-www-form-urlencoded",

        "Referer":
            SALES_URL,

        "User-Agent":
            "Mozilla/5.0"
    }

    print("📥 Downloading SALES 71...")

    def export_sales():

        res = session.post(
            SALES_URL,
            data=payload_export,
            headers=headers_normal
        )

        if len(res.content) < 1000:

            raise Exception(
                "71 sales file empty."
            )

        return res

    res = execute_with_retry(
        export_sales,
        step_name="EXPORT_71_SALES"
    )

    filename = (
        f"sales_71_"
        f"{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    )



    print("✅ SALES 71 ready → uploading...")

    send_email(
        "71 SALES DOWNLOADED",
        filename
    )

    upload_sales_to_supabase(
        res.content,
        allow_delete=False
    )

    print("🎉 SALES 71 COMPLETED")

    send_email(
        "71 SALES COMPLETED",
        "71 sales uploaded successfully."
    )
# =========================
# Stock Statement
# =========================
def download_stock_statement_pos():

    print("📦 STOCK STATEMENT (FINAL REAL FIX 🔥)")

    send_email(
        "STOCK STATEMENT STARTED",
        "Stock statement process started."
    )

    STOCK_URL = (
        "https://poszas.proactiveerp.com/"
        "Pages/StockStatementReport.aspx"
    )

    today = datetime.today()

    from_date = (
        today - timedelta(days=29)
    ).strftime("%Y-%m-%d")

    to_date = today.strftime(
        "%Y-%m-%d"
    )

    print(
        f"📅 FROM DATE: {from_date}"
    )

    print(
        f"📅 TO DATE: {to_date}"
    )

    send_email(
        "STOCK STATEMENT DATES",
        f"{from_date} → {to_date}"
    )

    # =========================
    # 🔐 LOGIN (Playwright → Cookies)
    # =========================
    cookies, headers_browser = (
        execute_with_retry(
            get_full_session_pos,
            step_name="POS_LOGIN"
        )
    )

    session = requests.Session()

    for c in cookies:

        session.cookies.set(
            c['name'],
            c['value']
        )

    headers = {
        "User-Agent":
            headers_browser["User-Agent"],

        "Referer":
            STOCK_URL,

        "Content-Type":
            "application/x-www-form-urlencoded"
    }

    # =========================
    # 📄 GET PAGE
    # =========================
    print("📄 Opening report page...")

    def open_stock_page():

        res = session.get(
            STOCK_URL,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening stock statement page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_stock_page,
        step_name="OPEN_STOCK_STATEMENT_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # 🔄 REFRESH
    # =========================
    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$ddlSalesType":
            "1",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    print("🔄 Refreshing stock statement...")

    def refresh_stock_statement():

        res = session.post(
            STOCK_URL,
            data=payload_refresh,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Stock statement refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_stock_statement,
        step_name="REFRESH_STOCK_STATEMENT"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # 📥 EXPORT
    # =========================
    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading stock statement...")

    def export_stock_statement():

        res = session.post(
            STOCK_URL,
            data=payload_export,
            headers=headers
        )

        # =========================
        # ❌ CHECK LOGIN / ERROR
        # =========================
        if (
            b"html"
            in res.content[:200].lower()
        ):

            raise Exception(
                "STILL LOGIN → session lost"
            )

        if len(res.content) < 1000:

            raise Exception(
                "EMPTY STOCK STATEMENT FILE"
            )

        return res

    res = execute_with_retry(
        export_stock_statement,
        step_name="EXPORT_STOCK_STATEMENT"
    )

    filename = (
        f"stock_statement_"
        f"{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    )



    print("✅ FILE READY → uploading to Supabase...")

    send_email(
        "STOCK STATEMENT DOWNLOADED",
        filename
    )

    upload_stk_statement_to_supabase(
        res.content
    )

    print("🎉 STOCK STATEMENT COMPLETED")

    send_email(
        "STOCK STATEMENT DOWNLOADED",
        filename
    )
#========================================================
def download_stock_statement_today_71():

    print("📦 STOCK STATEMENT (FINAL REAL FIX 🔥)")

    send_email(
        "STOCK STATEMENT 71 STARTED",
        "Stock statement process started."
    )

    STOCK_URL = (
        "https://poszas.proactiveerp.com/"
        "Pages/StockStatementReport.aspx"
    )

    today = datetime.today()

    today_str = datetime.today().strftime(
        "%Y-%m-%d"
    )

    from_date = today_str
    to_date = today_str

    print(
        f"📅 FROM DATE: {from_date}"
    )

    print(
        f"📅 TO DATE: {to_date}"
    )

    send_email(
        "STOCK STATEMENT DATES",
        f"{from_date} → {to_date}"
    )

    # =========================
    # 🔐 LOGIN (Playwright → Cookies)
    # =========================
    cookies, headers_browser = (
        execute_with_retry(
            get_full_session_pos_71,
            step_name="POS_LOGIN_71"
        )
    )

    session = convert_cookies_to_session(
        cookies
    )
    session = requests.Session()

    for c in cookies:

        session.cookies.set(
            c['name'],
            c['value']
        )
    headers = {
        "User-Agent":
            headers_browser["User-Agent"],
        "Referer":
            STOCK_URL,
        "Content-Type":
            "application/x-www-form-urlencoded"
    }

    # =========================
    # 📄 GET PAGE
    # =========================
    print("📄 Opening report page...")

    def open_stock_page():

        res = session.get(
            STOCK_URL,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening stock statement page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_stock_page,
        step_name="OPEN_STOCK_STATEMENT_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # 🔄 REFRESH
    # =========================
    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$ddlSalesType":
            "-1",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    print("🔄 Refreshing stock statement...")

    def refresh_stock_statement():

        res = session.post(
            STOCK_URL,
            data=payload_refresh,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Stock statement refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_stock_statement,
        step_name="REFRESH_STOCK_STATEMENT"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # 📥 EXPORT
    # =========================
    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading stock statement...")

    def export_stock_statement():

        res = session.post(
            STOCK_URL,
            data=payload_export,
            headers=headers
        )

        # =========================
        # ❌ CHECK LOGIN / ERROR
        # =========================
        if (
            b"html"
            in res.content[:200].lower()
        ):

            raise Exception(
                "STILL LOGIN → session lost"
            )

        if len(res.content) < 1000:

            raise Exception(
                "EMPTY STOCK STATEMENT FILE"
            )

        return res

    res = execute_with_retry(
        export_stock_statement,
        step_name="EXPORT_STOCK_STATEMENT"
    )

    filename = (
        f"stock_statement_today_71_"
        f"{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    )



    print("✅ FILE READY → uploading to Supabase...")

    send_email(
        "STOCK STATEMENT DOWNLOADED",
        filename
    )

    # =========================
    # 🚀 UPLOAD مباشرة
    # =========================
    upload_stk_statement_today_71(
        res.content
    )

    print("🎉 DONE FULL FLOW")

    send_email(
        "STOCK STATEMENT COMPLETED",
        "Stock statement uploaded successfully."
    )




#=======================================================


def download_stock_statement_71pos():

    print("📦 STOCK STATEMENT (FINAL REAL FIX 🔥)")

    send_email(
        "STOCK STATEMENT 71 STARTED",
        "Stock statement process started."
    )

    STOCK_URL = (
        "https://poszas.proactiveerp.com/"
        "Pages/StockStatementReport.aspx"
    )

    today = datetime.today()

    from_date = (
        today - timedelta(days=29)
    ).strftime("%Y-%m-%d")

    to_date = today.strftime(
        "%Y-%m-%d"
    )

    print(
        f"📅 FROM DATE: {from_date}"
    )

    print(
        f"📅 TO DATE: {to_date}"
    )

    send_email(
        "STOCK STATEMENT 71 DATES",
        f"{from_date} → {to_date}"
    )

    # =========================
    # 🔐 LOGIN (Playwright → Cookies)
    # =========================
    cookies, headers_browser = (
        execute_with_retry(
            get_full_session_pos_71,
            step_name="POS_LOGIN_71"
        )
    )

    session = convert_cookies_to_session(
        cookies
    )
    session = requests.Session()

    for c in cookies:

        session.cookies.set(
            c['name'],
            c['value']
        )
    headers = {
        "User-Agent":
            headers_browser["User-Agent"],
        "Referer":
            STOCK_URL,
        "Content-Type":
            "application/x-www-form-urlencoded"
    }

    # =========================
    # 📄 GET PAGE
    # =========================
    print("📄 Opening report page...")

    def open_stock_page():

        res = session.get(
            STOCK_URL,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening stock statement page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_stock_page,
        step_name="OPEN_STOCK_STATEMENT_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # 🔄 REFRESH
    # =========================
    payload_refresh = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            from_date,

        "ctl00$ContentPlaceHolder1$DatToDate":
            to_date,

        "ctl00$ContentPlaceHolder1$ddlSalesType":
            "1",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    print("🔄 Refreshing stock statement...")

    def refresh_stock_statement():

        res = session.post(
            STOCK_URL,
            data=payload_refresh,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Stock statement refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_stock_statement,
        step_name="REFRESH_STOCK_STATEMENT"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # 📥 EXPORT
    # =========================
    payload_export = {
        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading stock statement...")

    def export_stock_statement():

        res = session.post(
            STOCK_URL,
            data=payload_export,
            headers=headers
        )

        # =========================
        # ❌ CHECK LOGIN / ERROR
        # =========================
        if (
            b"html"
            in res.content[:200].lower()
        ):

            raise Exception(
                "STILL LOGIN → session lost"
            )

        if len(res.content) < 1000:

            raise Exception(
                "EMPTY STOCK STATEMENT FILE"
            )

        return res

    res = execute_with_retry(
        export_stock_statement,
        step_name="EXPORT_STOCK_STATEMENT"
    )

    filename = (
        f"stock_statement_"
        f"{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    )



    print("✅ FILE READY → uploading to Supabase...")

    send_email(
        "STOCK STATEMENT 71 DOWNLOADED",
        filename
    )

    # =========================
    # 🚀 UPLOAD مباشرة
    # =========================
    upload_stk_statement_to_supabase_71(
        res.content
    )

    print("🎉 DONE FULL FLOW")

    send_email(
        "STOCK STATEMENT COMPLETED",
        "Stock statement uploaded successfully."
    )

# =========================
# Upload STK Statement
# =========================
def upload_stk_statement_to_supabase(
    file_bytes
):

    print(
        "🚀 Uploading STOCK STATEMENT "
        "to Supabase..."
    )

    send_email(
        "STK STATEMENT UPLOAD STARTED",
        "Uploading stock statement started."
    )

    # =========================
    # READ EXCEL
    # =========================
    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    df.columns = (
        df.columns
        .str.strip()
    )

    print(
        "Columns:",
        df.columns.tolist()
    )

    send_email(
        "STK STATEMENT COLUMNS",
        str(df.columns.tolist())
    )

    # =========================
    # RENAME
    # =========================
    df = df.rename(columns={
        "Branch":
            "branch_name",

        "Item Code":
            "item_code",

        "Qty":
            "qty",

        "Trans Date":
            "trans_date",

        "Mode":
            "mode",

        "Trans Type":
            "trans_type"
    })

    required_columns = [
        "branch_name",
        "item_code",
        "qty",
        "trans_date",
        "mode",
        "trans_type"
    ]

    for col in required_columns:

        if col not in df.columns:

            error_msg = (
                f"Missing column: {col}"
            )

            print(error_msg)

            send_email(
                "STK STATEMENT ERROR",
                error_msg
            )

            return

    # =========================
    # FILTER (شرطك الأساسي)
    # =========================
    df = df[
        df["trans_type"]
        == "StockTransferTo"
    ]

    print(
        f"✅ After filter "
        f"(StockTransferTo): "
        f"{len(df)} rows"
    )

    send_email(
        "STK STATEMENT FILTERED",
        f"Rows after filter: {len(df)}"
    )

    # =========================
    # CLEAN DATA
    # =========================
    df["branch_name"] = (
        df["branch_name"]
        .astype(str)
        .str.strip()
    )

    df["item_code"] = (
        df["item_code"]
        .astype(str)
        .str.strip()
    )

    df["mode"] = (
        df["mode"]
        .astype(str)
        .str.strip()
    )

    df["qty"] = pd.to_numeric(
        df["qty"],
        errors="coerce"
    ).fillna(0)

    df["trans_date"] = pd.to_datetime(
        df["trans_date"],
        dayfirst=True,
        errors="coerce"
    )

    # =========================
    # 🔥 CONDITION DATE
    # =========================
    df["trans_date"] = pd.to_datetime(
        df["trans_date"],
        dayfirst=True,
        errors="coerce"
    ).dt.date

    df["trans_date"] = (
        df["trans_date"]
        .astype(str)
    )

    # =========================
    # FINAL COLUMNS
    # =========================
    df = df[[
        "branch_name",
        "item_code",
        "qty",
        "trans_date",
        "mode"
    ]]

    df["created_at"] = (
        datetime.utcnow()
        .isoformat()
    )

    df = df.fillna("")

    data = df.to_dict(
        orient="records"
    )

    print(
        f"📊 Final rows: "
        f"{len(data)}"
    )

    send_email(
        "STK STATEMENT FINAL ROWS",
        f"Final rows count: {len(data)}"
    )

    # =========================
    # HEADERS
    # =========================
    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # 🧹 DELETE OLD DATA
    # =========================
    print(
        "🧹 Clearing stk_statement table..."
    )

    execute_with_retry(
        lambda: run_rpc(
            "truncate_stk_statement"
        ),
        step_name="TRUNCATE_STK_STATEMENT"
    )

    print("✅ Table cleared")

    send_email(
        "STK STATEMENT CLEARED",
        "stk_statement table truncated."
    )

    # =========================
    # 📤 INSERT
    # =========================
    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/stk_statement",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"STK_STATEMENT_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} inserted"
        )

       

    print(
        "🎉 STOCK STATEMENT "
        "uploaded successfully"
    )

    send_email(
        "STK STATEMENT COMPLETED",
        "Stock statement uploaded successfully."
    )

# =========================
# UPLOAD STK STATEMENT TODAY
# =========================
def upload_stk_statement_today(file_bytes):

    print("🚀 Uploading STK STATEMENT TODAY")

    send_email(
        "START STK TODAY UPLOAD",
        "Uploading realtime sales"
    )

    # =========================
    # READ EXCEL
    # =========================
    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    # =========================
    # CLEAN COLUMNS
    # =========================
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    print(df.columns.tolist())

    # =========================
    # RENAME
    # =========================
    df = df.rename(columns={

        "branch":
            "branch_name",

        "item code":
            "item_code",

        "item name":
            "item_name",

        "qty":
            "qty",

        "trans date":
            "trans_date",

        "mode":
            "mode",

        "trans type":
            "trans_type"
    })

    # =========================
    # KEEP ONLY NEEDED
    # =========================
    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "qty",
        "trans_date",
        "mode",
        "trans_type"
    ]]

    # =========================
    # CLEAN TEXT
    # =========================
    df["branch_name"] = (
        df["branch_name"]
        .astype(str)
        .str.strip()
    )

    df["item_code"] = (
        df["item_code"]
        .astype(str)
        .str.strip()
    )

    df["item_name"] = (
        df["item_name"]
        .astype(str)
        .str.strip()
    )

    df["mode"] = (
        df["mode"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    df["trans_type"] = (
        df["trans_type"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    # =========================
    # CLEAN QTY
    # =========================
    df["qty"] = pd.to_numeric(
        df["qty"],
        errors="coerce"
    ).fillna(0)

    # =========================
    # 🔥 CONVERT NEGATIVE TO POSITIVE
    # =========================
    df["qty"] = df["qty"].abs()

    # =========================
    # DATE
    # =========================
    df["trans_date"] = pd.to_datetime(
        df["trans_date"],
        errors="coerce"
    ).dt.strftime("%Y-%m-%d")

    # =========================
    # FILTER
    # =========================
    df = df[

        (
            df["mode"] == "OUT"
        )

        &

        (
            df["trans_type"].isin([
                "POS",
                "POSDVN"
            ])
        )

        &

        (
            df["qty"] != 0
        )
    ]

    print(
        f"✅ Filtered Rows Before Grouping: "
        f"{len(df)}"
    )

    # =========================
    # 🔥 GROUP LIKE PIVOT TABLE
    # =========================
    df = df.groupby(
        [
            "branch_name",
            "item_code"
        ],
        as_index=False
    ).agg({

        "item_name":
            "first",

        "qty":
            "sum",

        "trans_date":
            "first",

        "mode":
            "first"
    })

    print(
        f"✅ Rows After Grouping: "
        f"{len(df)}"
    )

    print(
        f"✅ Total Qty: "
        f"{df['qty'].sum()}"
    )

    send_email(
        "STK TODAY GROUPED",
        f"Rows After Grouping: {len(df)}\n"
        f"Total Qty: {df['qty'].sum()}"
    )

    # =========================
    # FINAL COLUMNS
    # =========================
    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "qty",
        "trans_date",
        "mode"
    ]]

    # =========================
    # CREATED AT
    # =========================
    df["created_at"] = (
        datetime.utcnow()
        .isoformat()
    )

    # =========================
    # FILL NULL
    # =========================
    df = df.fillna("")

    # =========================
    # TO JSON
    # =========================
    data = df.to_dict(
        orient="records"
    )

    print(
        f"📊 Final Rows Ready Upload: "
        f"{len(data)}"
    )

    send_email(
        "STK TODAY READY",
        f"Rows ready upload: {len(data)}"
    )

    # =========================
    # HEADERS
    # =========================
    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

    # =========================
    # CLEAR TABLE
    # =========================
    print(
        "🧹 Clearing realtime table..."
    )

    execute_with_retry(
        lambda: run_rpc(
            "truncate_stk_statement_today"
        ),
        step_name=
            "TRUNCATE_STK_STATEMENT_TODAY"
    )

    print("✅ Table cleared")

    # =========================
    # INSERT
    # =========================
    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/stk_statement_today",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"STK_TODAY_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} inserted"
        )

    print(
        "🎉 STK TODAY uploaded successfully"
    )

    send_email(
        "STK TODAY COMPLETED",
        "Realtime sales uploaded successfully."
    )

# =========================
# TODAY SALES FROM STOCK STATEMENT 71
# =========================

def upload_stk_statement_today_71(file_bytes):

    print("🚀 Uploading STK STATEMENT 71 TODAY")

    send_email(
        "START STK TODAY 71 UPLOAD",
        "Uploading realtime sales"
    )

    # =========================
    # READ EXCEL
    # =========================
    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    # =========================
    # CLEAN COLUMNS
    # =========================
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    print(df.columns.tolist())

    # =========================
    # RENAME
    # =========================
    df = df.rename(columns={

        "branch":
            "branch_name",

        "item code":
            "item_code",

        "item name":
            "item_name",

        "qty":
            "qty",

        "trans date":
            "trans_date",

        "mode":
            "mode",

        "trans type":
            "trans_type"
    })

    # =========================
    # KEEP ONLY NEEDED
    # =========================
    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "qty",
        "trans_date",
        "mode",
        "trans_type"
    ]]

    # =========================
    # CLEAN TEXT
    # =========================
    df["branch_name"] = (
        df["branch_name"]
        .astype(str)
        .str.strip()
    )

    df["item_code"] = (
        df["item_code"]
        .astype(str)
        .str.strip()
    )

    df["item_name"] = (
        df["item_name"]
        .astype(str)
        .str.strip()
    )

    df["mode"] = (
        df["mode"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    df["trans_type"] = (
        df["trans_type"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    # =========================
    # CLEAN QTY
    # =========================
    df["qty"] = pd.to_numeric(
        df["qty"],
        errors="coerce"
    ).fillna(0)

    # =========================
    # 🔥 CONVERT NEGATIVE TO POSITIVE
    # =========================
    df["qty"] = df["qty"].abs()

    # =========================
    # DATE
    # =========================
    df["trans_date"] = pd.to_datetime(
        df["trans_date"],
        errors="coerce"
    ).dt.strftime("%Y-%m-%d")

    # =========================
    # FILTER
    # =========================
    df = df[

        (
            df["mode"] == "OUT"
        )

        &

        (
            df["trans_type"].isin([
                "POS",
                "POSDVN"
            ])
        )

        &

        (
            df["qty"] != 0
        )
    ]

    print(
        f"✅ Filtered Rows Before Grouping: "
        f"{len(df)}"
    )

    # =========================
    # 🔥 GROUP LIKE PIVOT TABLE
    # =========================
    df = df.groupby(
        [
            "branch_name",
            "item_code"
        ],
        as_index=False
    ).agg({

        "item_name":
            "first",

        "qty":
            "sum",

        "trans_date":
            "first",

        "mode":
            "first"
    })

    print(
        f"✅ Rows After Grouping: "
        f"{len(df)}"
    )

    print(
        f"✅ Total Qty: "
        f"{df['qty'].sum()}"
    )

    send_email(
        "STK TODAY 71 GROUPED",
        f"Rows After Grouping: {len(df)}\n"
        f"Total Qty: {df['qty'].sum()}"
    )

    # =========================
    # FINAL COLUMNS
    # =========================
    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "qty",
        "trans_date",
        "mode"

    ]]

    # =========================
    # CREATED AT
    # =========================
    df["created_at"] = (
        datetime.utcnow()
        .isoformat()
    )
    df["company"] = (
         "71 Pharmacy L.L.C."
    )
    df = df[[
        "branch_name",
        "item_code",
        "item_name",
        "qty",
        "trans_date",
        "mode",
        "company",
        "created_at"
    ]]
    # =========================
    # FILL NULL
    # =========================
    df = df.fillna("")

    # =========================
    # TO JSON
    # =========================
    data = df.to_dict(
        orient="records"
    )

    print(
        f"📊 Final Rows Ready Upload: "
        f"{len(data)}"
    )

    send_email(
        "STK TODAY 71 READY",
        f"Rows ready upload: {len(data)}"
    )

    # =========================
    # HEADERS
    # =========================
    headers = {
        "apikey":
            SUPABASE_KEY,

        "Authorization":
            f"Bearer {SUPABASE_KEY}",

        "Content-Type":
            "application/json",

        "Prefer":
            "return=minimal"
    }

 

    # =========================
    # INSERT
    # =========================
    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/stk_statement_today",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
                f"STK_TODAY_BATCH_"
                f"{i // batch_size + 1}"
        )

        print(
            f"✅ Batch "
            f"{i // batch_size + 1} inserted"
        )

    print(
        "🎉 STK TODAY 71 uploaded successfully"
    )

    send_email(
        "STK TODAY 71 COMPLETED",
        "Realtime sales uploaded successfully."
    )


# =========================
# TODAY SALES FROM STOCK STATEMENT
# =========================
def download_stock_statement_today_sales():

    print("📦 TODAY SALES")

    send_email(
        "TODAY SALES STARTED",
        "Realtime today sales started."
    )

    STOCK_URL = (
        "https://poszas.proactiveerp.com/"
        "Pages/StockStatementReport.aspx"
    )

    today = datetime.today().strftime(
        "%Y-%m-%d"
    )

    print(f"📅 TODAY: {today}")

    # =========================
    # LOGIN
    # =========================
    cookies, headers_browser = (
        execute_with_retry(
            get_full_session_pos,
            step_name="POS_LOGIN_TODAY"
        )
    )

    session = requests.Session()

    for c in cookies:

        session.cookies.set(
            c['name'],
            c['value']
        )

    headers = {
        "User-Agent":
            headers_browser["User-Agent"],

        "Referer":
            STOCK_URL,

        "Content-Type":
            "application/x-www-form-urlencoded"
    }

    # =========================
    # OPEN PAGE
    # =========================
    def open_page():

        res = session.get(
            STOCK_URL,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_page,
        step_name="OPEN_TODAY_SALES_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # REFRESH
    # =========================
    payload_refresh = {

        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            today,

        "ctl00$ContentPlaceHolder1$DatToDate":
            today,

        "ctl00$ContentPlaceHolder1$ddlSalesType":
            "-1",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    print("🔄 Refreshing today sales...")

    def refresh_today_sales():

        res = session.post(
            STOCK_URL,
            data=payload_refresh,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_today_sales,
        step_name="REFRESH_TODAY_SALES"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # EXPORT
    # =========================
    payload_export = {

        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading today sales...")

    def export_today_sales():

        res = session.post(
            STOCK_URL,
            data=payload_export,
            headers=headers
        )

        if (
            b"html"
            in res.content[:200].lower()
        ):

            raise Exception(
                "Session expired"
            )

        if len(res.content) < 1000:

            raise Exception(
                "Today sales file empty"
            )

        return res

    res = execute_with_retry(
        export_today_sales,
        step_name="EXPORT_TODAY_SALES"
    )

    filename = (
        f"today_sales_"
        f"{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    )



    print("✅ TODAY SALES FILE READY")

    send_email(
        "TODAY SALES DOWNLOADED",
        filename
    )

    # =========================
    # UPLOAD
    # =========================
    upload_stk_statement_today(
        res.content
    )

    print("🎉 TODAY SALES DONE")

    send_email(
        "TODAY SALES COMPLETED",
        "Realtime today sales uploaded successfully."
    )

def upload_stk_statement_to_supabase_71(file_bytes):

    print("🚀 Uploading STOCK STATEMENT 71")

    df = pd.read_excel(
        BytesIO(file_bytes)
    )

    df.columns = (
        df.columns
        .str.strip()
    )

    df = df.rename(columns={
        "Branch": "branch_name",
        "Item Code": "item_code",
        "Qty": "qty",
        "Trans Date": "trans_date",
        "Mode": "mode",
        "Trans Type": "trans_type"
    })

    df = df[
        df["trans_type"]
        == "StockTransferTo"
    ]

    allowed_branches = [
        "Zakher Branch",
        "Asharej Branch",
        "Ayla Branch"
    ]

    df = df[
        df["branch_name"]
        .isin(allowed_branches)
    ]

    df["company"] = "71 Pharmacy L.L.C."

    df["qty"] = pd.to_numeric(
        df["qty"],
        errors="coerce"
    ).fillna(0)

    df["trans_date"] = pd.to_datetime(
        df["trans_date"],
        dayfirst=True,
        errors="coerce"
    ).dt.date.astype(str)

    df["created_at"] = (
        datetime.utcnow()
        .isoformat()
    )

    df = df[[
        "branch_name",
        "item_code",
        "qty",
        "trans_date",
        "mode",
        "company",
        "created_at"
    ]]

    df = df.fillna("")

    data = df.to_dict(
        orient="records"
    )

    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization":
            f"Bearer {SUPABASE_KEY}",
        "Content-Type":
            "application/json",
        "Prefer":
            "return=minimal"
    }


    batch_size = 5000

    for i in range(
        0,
        len(data),
        batch_size
    ):

        batch = data[
            i:i + batch_size
        ]

        def upload_batch():

            res = requests.post(
                f"{SUPABASE_URL}/rest/v1/stk_statement",
                json=batch,
                headers=headers
            )

            if res.status_code not in [200, 201]:

                raise Exception(
                    res.text
                )

        execute_with_retry(
            upload_batch,
            step_name=
            f"INSERT_71_STK_STATEMENT_"
            f"{i // batch_size + 1}"
        )

    print("🎉 71 Stock Statement Uploaded")


# =========================
# POS Session
# =========================
def get_full_session_pos():

    from playwright.sync_api import (
        sync_playwright
    )

    send_email(
        "POS LOGIN STARTED",
        "Starting POS login."
    )

    with sync_playwright() as p:

        browser = p.chromium.launch(
            headless=True
        )

        context = browser.new_context()

        page = context.new_page()

        print("🔐 Logging in POS...")

        # =========================
        # LOGIN
        # =========================
        page.goto(
            "https://poszas.proactiveerp.com/Account/Login"
        )

        page.fill(
            'input[name="UserName"]',
            USERNAME
        )

        page.fill(
            'input[name="Password"]',
            PASSWORD
        )

        page.click(
            'input[type="submit"]'
        )

        # =========================
        # SELECT COMPANY
        # =========================
        page.wait_for_selector(
            "select"
        )

        page.select_option(
            "select",
            label="Al Ain Pharmacy Group (APG)"
        )

        page.click(
            "#btnSelectCompany"
        )

        page.wait_for_load_state(
            "networkidle"
        )

        # =========================
        # 🔥 IMPORTANT: OPEN REPORT PAGE
        # =========================
        page.goto(
            "https://poszas.proactiveerp.com/"
            "Pages/StockStatementReport.aspx"
        )

        page.wait_for_load_state(
            "networkidle"
        )

        print("✅ Report page loaded")

        send_email(
            "POS REPORT PAGE READY",
            "POS report page loaded successfully."
        )

        cookies = context.cookies()

        # 🔥 خذ أيضاً headers
        headers = page.evaluate(
            """() => {
                return {
                    'User-Agent': navigator.userAgent
                }
            }"""
        )

        browser.close()

        send_email(
            "POS LOGIN SUCCESS",
            "POS session ready."
        )

        return cookies, headers

def get_full_session_pos_71():

    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:

        browser = p.chromium.launch(
            headless=True
        )

        context = browser.new_context()

        page = context.new_page()

        page.goto(
            "https://poszas.proactiveerp.com/Account/Login"
        )

        page.fill(
            'input[name="UserName"]',
            USERNAME
        )

        page.fill(
            'input[name="Password"]',
            PASSWORD
        )

        page.click(
            'input[type="submit"]'
        )

        page.wait_for_selector(
            "select"
        )

        page.select_option(
            "select",
            label="71 Pharmacy L.L.C."
        )

        page.click(
            "#btnSelectCompany"
        )

        page.wait_for_load_state(
            "networkidle"
        )

        page.goto(
            "https://poszas.proactiveerp.com/Pages/StockStatementReport.aspx"
        )

        page.wait_for_load_state(
            "networkidle"
        )

        cookies = context.cookies()

        headers = page.evaluate(
            """() => ({
                'User-Agent':
                    navigator.userAgent
            })"""
        )

        browser.close()

        return cookies, headers
# =========================
# RUN
# =========================
def run_legacy():

    print("🚀 START JOB")

    send_email(
        "JOB STARTED",
        "All processes started."
    )

    try:

        cookies = execute_with_retry(
            lambda: get_session_cookies(),
            step_name="MAIN_LOGIN"
        )

        session = convert_cookies_to_session(cookies)

        download_transfer(session)

        download_sales_45d(session)

      


    
        download_stk(session)

        download_item_report(session)

        download_stk_71()

        download_sales_71()

        download_stock_statement_pos()

        download_stock_statement_today_sales()

        download_stock_statement_today_71()

        download_stock_statement_71pos()

        print("🎉 ALL JOBS COMPLETED")

        send_email(
            "JOB COMPLETED",
            "All jobs completed successfully."
        )

    except Exception as e:

        print(f"❌ JOB FAILED: {e}")

        send_email(
            "JOB FAILED",
            str(e)
        )

        raise


def run():

    print("START JOB")

    send_email(
        "JOB STARTED",
        "All processes started."
    )

    cookies = execute_with_retry(
        lambda: get_session_cookies(),
        step_name="MAIN_LOGIN"
    )

    session = convert_cookies_to_session(cookies)

    reports = [
        {
            "name": "TRANSFER",
            "func": lambda: download_transfer(session),
            "depends_on": [],
        },
        {
            "name": "SALES_45D",
            "func": lambda: download_sales_45d(session),
            "depends_on": [],
        },
        {
            "name": "STK",
            "func": lambda: download_stk(session),
            "depends_on": [],
        },
        {
            "name": "ITEM_REPORT",
            "func": lambda: download_item_report(session),
            "depends_on": [],
        },
        {
            "name": "STK_71",
            "func": download_stk_71,
            "depends_on": ["STK"],
        },
        {
            "name": "SALES_71",
            "func": download_sales_71,
            "depends_on": ["SALES_45D"],
        },
        {
            "name": "STOCK_STATEMENT_POS",
            "func": download_stock_statement_pos,
            "depends_on": [],
        },
        {
            "name": "TODAY_SALES",
            "func": download_stock_statement_today_sales,
            "depends_on": [],
        },
        {
            "name": "TODAY_71",
            "func": download_stock_statement_today_71,
            "depends_on": ["TODAY_SALES"],
        },
        {
            "name": "STOCK_STATEMENT_71POS",
            "func": download_stock_statement_71pos,
            "depends_on": ["STOCK_STATEMENT_POS"],
        },
    ]

    completed = set()
    deferred = []
    deferred_names = set()
    final_failed = {}

    def defer_report(report, reason):
        if report["name"] not in deferred_names:
            deferred.append(report)
            deferred_names.add(report["name"])

        print(
            f"DEFERRED REPORT: {report['name']} - {reason}"
        )

        send_email(
            f"REPORT DEFERRED - {report['name']}",
            reason
        )

    def run_report(report, final_retry=False):
        phase = "FINAL RETRY" if final_retry else "MAIN PASS"

        print(f"{phase}: {report['name']}")

        send_email(
            f"REPORT STARTED - {report['name']}",
            f"{phase} started."
        )

        try:
            report["func"]()

        except Exception as e:
            error_text = (
                f"{report['name']} failed during {phase}.\n\n"
                f"{str(e)}\n\n"
                f"{traceback.format_exc()}"
            )

            print(error_text)

            send_email(
                f"REPORT FAILED - {report['name']}",
                error_text
            )

            return False

        completed.add(report["name"])

        send_email(
            f"REPORT COMPLETED - {report['name']}",
            f"{report['name']} completed successfully."
        )

        return True

    for report in reports:
        missing_deps = [
            dep
            for dep in report["depends_on"]
            if dep not in completed
        ]

        if missing_deps:
            defer_report(
                report,
                "Waiting for required report(s): "
                + ", ".join(missing_deps)
            )
            continue

        if not run_report(report):
            defer_report(
                report,
                "Will retry at the end of the job."
            )

    while deferred:
        progress = False
        still_deferred = []

        for report in deferred:
            missing_deps = [
                dep
                for dep in report["depends_on"]
                if dep not in completed
            ]

            if missing_deps:
                still_deferred.append(report)
                continue

            progress = True

            if not run_report(report, final_retry=True):
                final_failed[report["name"]] = (
                    "Failed again during final retry."
                )

        if not progress:
            for report in still_deferred:
                missing_deps = [
                    dep
                    for dep in report["depends_on"]
                    if dep not in completed
                ]
                final_failed[report["name"]] = (
                    "Skipped because required report(s) failed: "
                    + ", ".join(missing_deps)
                )
            break

        deferred = [
            report
            for report in still_deferred
            if report["name"] not in final_failed
        ]
        deferred_names = {
            report["name"]
            for report in deferred
        }

    if final_failed:
        failed_text = "\n".join(
            f"{name}: {reason}"
            for name, reason in final_failed.items()
        )

        print(f"JOB COMPLETED WITH FAILURES:\n{failed_text}")

        send_email(
            "JOB COMPLETED WITH FAILURES",
            failed_text
        )

        raise Exception(failed_text)

    print("ALL JOBS COMPLETED")

    send_email(
        "JOB COMPLETED",
        "All jobs completed successfully."
    )


if __name__ == "__main__":

    run()
