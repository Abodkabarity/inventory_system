from main import (
    execute_with_retry,
    get_full_session_pos,
    extract_value,
    upload_stk_statement_today,
    send_email
)

import requests

from datetime import datetime

# =========================
# TODAY SALES
# =========================
def download_stock_statement_today_sales():

    print("📦 TODAY SALES")

    send_email(
        "TODAY SALES STARTED",
        "Realtime today sales started."
    )

    STOCK_URL = (
        "https://poszas.proactiveerp.com/"
        "Pages/StockStatementReport.aspx"
    )

    today = datetime.today().strftime(
        "%Y-%m-%d"
    )

    print(f"📅 TODAY: {today}")

    # =========================
    # LOGIN
    # =========================
    cookies, headers_browser = (
        execute_with_retry(
            get_full_session_pos,
            step_name="POS_LOGIN_TODAY"
        )
    )

    session = requests.Session()

    for c in cookies:

        session.cookies.set(
            c['name'],
            c['value']
        )

    headers = {
        "User-Agent":
            headers_browser["User-Agent"],

        "Referer":
            STOCK_URL,

        "Content-Type":
            "application/x-www-form-urlencoded"
    }

    # =========================
    # OPEN PAGE
    # =========================
    def open_page():

        res = session.get(
            STOCK_URL,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Failed opening page: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        open_page,
        step_name=
            "OPEN_TODAY_SALES_PAGE"
    )

    html = res.text

    viewstate = extract_value(
        "__VIEWSTATE",
        html
    )

    gen = extract_value(
        "__VIEWSTATEGENERATOR",
        html
    )

    # =========================
    # REFRESH
    # =========================
    payload_refresh = {

        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "ctl00$ContentPlaceHolder1$DatFromDate":
            today,

        "ctl00$ContentPlaceHolder1$DatToDate":
            today,

        "ctl00$ContentPlaceHolder1$ddlSalesType":
            "-1",

        "ctl00$ContentPlaceHolder1$bntGVRefresh":
            "Refresh"
    }

    print("🔄 Refreshing today sales...")

    def refresh_today_sales():

        res = session.post(
            STOCK_URL,
            data=payload_refresh,
            headers=headers
        )

        if res.status_code != 200:

            raise Exception(
                f"Refresh failed: "
                f"{res.text}"
            )

        return res

    res = execute_with_retry(
        refresh_today_sales,
        step_name=
            "REFRESH_TODAY_SALES"
    )

    viewstate = extract_value(
        "__VIEWSTATE",
        res.text
    )

    # =========================
    # EXPORT
    # =========================
    payload_export = {

        "__VIEWSTATE":
            viewstate,

        "__VIEWSTATEGENERATOR":
            gen,

        "__EVENTTARGET":
            "ctl00$ContentPlaceHolder1$btnXlsxExport"
    }

    print("📥 Downloading today sales...")

    def export_today_sales():

        res = session.post(
            STOCK_URL,
            data=payload_export,
            headers=headers
        )

        # =========================
        # CHECK HTML
        # =========================
        if (
            b"html"
            in res.content[:200].lower()
        ):

            raise Exception(
                "Session expired"
            )

        if len(res.content) < 1000:

            raise Exception(
                "Today sales file empty"
            )

        return res

    res = execute_with_retry(
        export_today_sales,
        step_name=
            "EXPORT_TODAY_SALES"
    )

    filename = (
        f"today_sales_"
        f"{datetime.today().strftime('%Y-%m-%d_%H-%M-%S')}.xlsx"
    )

    with open(
        filename,
        "wb"
    ) as f:

        f.write(res.content)

    print(
        "✅ TODAY SALES FILE READY"
    )

    send_email(
        "TODAY SALES DOWNLOADED",
        filename
    )

    # =========================
    # UPLOAD
    # =========================
    upload_stk_statement_today(
        res.content
    )

    print(
        "🎉 TODAY SALES DONE"
    )

    send_email(
        "TODAY SALES COMPLETED",
        "Realtime today sales uploaded successfully."
    )


# =========================
# MAIN
# =========================
if __name__ == "__main__":

    try:

        download_stock_statement_today_sales()

    except Exception as e:

        print(f"❌ ERROR: {e}")

        send_email(
            "TODAY SALES FAILED",
            str(e)
        )