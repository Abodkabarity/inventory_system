import ctypes
import schedule
import time
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# =========================
# PREVENT SLEEP
# =========================

ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001

ctypes.windll.kernel32.SetThreadExecutionState(
    ES_CONTINUOUS | ES_SYSTEM_REQUIRED
)

# =========================
# FILE PATHS
# =========================

AUTOMATION_DIR = Path(__file__).resolve().parent

MAIN_JOB = AUTOMATION_DIR / "main.py"
DAILY_ORDER_JOB = AUTOMATION_DIR / "update_final_reorder_batch.py"

EXPORT_JOB = AUTOMATION_DIR / "export.py"

HISTORY_EXPORT_JOB = AUTOMATION_DIR / "history_export.py"

PYTHON_EXE = sys.executable

# =========================
# RUN FUNCTIONS
# =========================

def run_main_job():
    try:
        print(
            f"[{datetime.now()}] "
            f"START MAIN JOB"
        )

        result = subprocess.run([
            PYTHON_EXE,
            str(MAIN_JOB)
        ])

    except Exception as e:
        print(
            f"[{datetime.now()}] "
            f"ERROR MAIN JOB: {e}"
        )
        return

    if result.returncode == 0:
        print(
            f"[{datetime.now()}] "
            f"MAIN JOB COMPLETED"
        )
        run_daily_order_job()
    else:
        print(
            f"[{datetime.now()}] "
            f"MAIN JOB FAILED WITH EXIT CODE {result.returncode}. "
            f"DAILY ORDER JOB SKIPPED"
        )

def run_daily_order_job():
    try:
        print(
            f"[{datetime.now()}] "
            f"START DAILY ORDER JOB"
        )

        subprocess.run([
            PYTHON_EXE,
            str(DAILY_ORDER_JOB),
            "--db-password", "0991714051@Abd",
            "--db-host", "aws-1-ap-northeast-2.pooler.supabase.com",
            "--db-user", "postgres.rzvxjkbraufqbfhvftcy",
            "--db-port", "5432",
            "--base-batch-size", "20000",
            "--skip-install-base-function",
        ], check=True)

        print(
            f"[{datetime.now()}] "
            f"END DAILY ORDER JOB"
        )

    except subprocess.CalledProcessError as e:
        print(
            f"[{datetime.now()}] "
            f"ERROR DAILY ORDER JOB: EXIT CODE {e.returncode}"
        )

    except Exception as e:
        print(
            f"[{datetime.now()}] "
            f"ERROR DAILY ORDER JOB: {e}"
        )

def run_export_job():
    try:
        print(
            f"[{datetime.now()}] "
            f"START EXPORT JOB"
        )

        subprocess.Popen([
            PYTHON_EXE,
            str(EXPORT_JOB)
        ])

        print(
            f"[{datetime.now()}] "
            f"EXPORT JOB STARTED"
        )

    except Exception as e:
        print(
            f"[{datetime.now()}] "
            f"ERROR EXPORT JOB: {e}"
        )

def run_history_export_job():
    try:
        print(
            f"[{datetime.now()}] "
            f"START HISTORY EXPORT JOB"
        )

        subprocess.Popen([
            PYTHON_EXE,
            str(HISTORY_EXPORT_JOB)
        ])

        print(
            f"[{datetime.now()}] "
            f"HISTORY EXPORT JOB STARTED"
        )

    except Exception as e:
        print(
            f"[{datetime.now()}] "
            f"ERROR HISTORY EXPORT JOB: {e}"
        )
# =========================
# SCHEDULES
# =========================

# MAIN JOB
# EVERY DAY 8 PM UAE

schedule.every().day.at("10:35").do(
    run_main_job
)
# EXPORT JOB
# EVERY DAY 1 AM UAE

schedule.every().day.at("01:00").do(
    run_export_job
)
# HISTORY EXPORT JOB
# EVERY DAY 3 AM UAE

schedule.every().day.at("12:00").do(
    run_history_export_job
)

print("✅ Scheduler Started...")

# =========================
# LOOP
# =========================

while True:
    try:
        schedule.run_pending()

    except Exception as e:
        print(
            f"[{datetime.now()}] "
            f"SCHEDULER ERROR: {e}"
        )

    time.sleep(30)
