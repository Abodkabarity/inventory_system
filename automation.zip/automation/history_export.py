from supabase import create_client
import os
from openpyxl import Workbook
from openpyxl.styles import (
    Font,
    PatternFill,
    Border,
    Side,
    Alignment,
)
from openpyxl.cell import WriteOnlyCell
from openpyxl.utils import get_column_letter

# =========================
# SUPABASE
# =========================

SUPABASE_URL = "https://rzvxjkbraufqbfhvftcy.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6dnhqa2JyYXVmcWJmaHZmdGN5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTI3MTIwMCwiZXhwIjoyMDg2ODQ3MjAwfQ.D1QxC_yshFdCbKPU5UmEFOM6hw3vdQRYO2_5_KatW6c"


supabase = create_client(
    SUPABASE_URL,
    SUPABASE_KEY
)

# =========================
# TITLES
# =========================

TITLES = {
    'branch': 'BRANCH',
    'item_code': 'ITEM CODE',
    'item_name': 'ITEM NAME',
    'goods_received_last_7_days':
        'GOODS RECEIVED\nOF LAST 7 DAYS',

    'branch_stock': 'Branch Stock',
    'mismatch_stock': 'MISMATCH\nSTOCK',
    'store_stock': 'STORE STOCK',
    'pending_stock_received':
        'PENDING\nSTOCK\nRECEIVED',

    'extra_qty_more_than_month':
        'Extra QTY\n(More Than Month)',

    'max_adjustment_30d':
        'MAX\nADJUSTMENT\n(30 DAYS\nDEMAND BY\nBRANCH)',

    'reason':
        'REASON FOR MAX\nADJUSTMENT (30\nDAYS DEMAND BY\nBRANCH)',

    'demand_for_30_days':
        'DEMAND FOR\n30 DAYS',

    'reorder_point_min':
        'REORDER\nPOINT (MIN)',

    'reorder_max':
        'REORDER\nMAX',

    'reorder_qty':
        'REORDER QTY',

    'final_reorder_qty_store_stock_gt_0':
        'Final Re Order QTY\n(Store Stock >0)',

    'date_of_last_qty_received_in_branch':
        'DATE OF LAST QTY\nRECEIVED IN BRANCH',

    'qty_30_days_from_last_45d':
        '30 Days QTY (From\nLast 45 D)',

    'branch_formulary':
        'Branch Formulary',

    'assortment_qty_base_stock':
        'Assortment Qty /\nBase Stock',

    'assortment_by':
        'Assortment By',

    'assortment_start':
        'Assortment Start',

    'assortment_end':
        'Assortment End',

    'tma_qty':
        'TMA Qty',

    'tma_start':
        'TMA Start',

    'tma_end':
        'TMA End',

    'item_purchase_type':
        'Item purchase type\n(item status)',

    'sales_orientation':
        'SALES\nORIANTATION',

    'category':
        'CATEGORY',

    'sub_category':
        'Sub-Category',

    'company':
        'Company',

    'supplier':
        'SUPPLIER',

    'indication':
        'Indication',

    'active_ingredient':
        'ACTIVE INGREDIANT',

    'pack_size':
        'Pack Size',

    'concentration':
        'Concentration',

    'product_type_form':
        'Product Type/Form',

    'retail_price':
        'RETAIL PRICE',

    'vat':
        'VAT',

    'is_upp':
        'IS UPP',

    'item_minimum_order_unit':
        'ITEM MINIMUM\nORDER UNIT',

    'barcode':
        'BARCODE',

    'store_item_classifications':
        'STORE ITEM\nCLASSIFICATIONS',
}

# =========================
# COLUMNS
# =========================

COLUMNS = list(TITLES.keys())

# =========================
# RUN DATE
# =========================

from datetime import date

run_date = date.today().isoformat()

print(
    f"START EXPORT {run_date}"
)


# =========================
# GET ALL BRANCHES
# =========================

# =========================
# GET ALL BRANCHES
# =========================
from datetime import datetime

today_name = datetime.today().strftime("%A")

print(f"TODAY = {today_name}")

branches_response = (
    supabase
    .table("branches")
    .select(
        "branch_name,order_days"
    )
    .eq("is_active", True)
    .execute()
)

branches = []

for row in branches_response.data:

    order_days = row.get("order_days") or []

    if today_name in order_days:

        branches.append(
            row["branch_name"]
        )

print(
    f"TOTAL BRANCHES FOR TODAY: {len(branches)}"
)

print(
    f"TOTAL BRANCHES: {len(branches)}"
)

# =========================
# COLORS
# =========================

GREEN = "C6E0B4"
BLUE = "BDD7EE"
YELLOW = "FFE699"
LIGHT_GREEN = "E2EFDA"
PEACH = "F8CBAD"
LIGHT_BLUE = "B4C6E7"
GRAY = "D9D9D9"

# =========================
# BORDER
# =========================

thin = Side(
    style="thin",
    color="000000"
)

border = Border(
    left=thin,
    right=thin,
    top=thin,
    bottom=thin
)

# =========================
# HEADER STYLE
# =========================

header_font = Font(
    bold=True,
    size=10,
    color="000000"
)

# =========================
# GROUP COLORS
# =========================

def get_fill(column):

    if column in [
        "branch",
        "item_code",
        "item_name",
    ]:
        color = GREEN

    elif column in [
        "branch_stock",
        "mismatch_stock",
        "store_stock",
        "pending_stock_received",
        "extra_qty_more_than_month",
    ]:
        color = BLUE

    elif column in [
        "max_adjustment_30d",
        "reason",
        "demand_for_30_days",
        "reorder_point_min",
        "reorder_max",
        "reorder_qty",
        "final_reorder_qty_store_stock_gt_0",
    ]:
        color = YELLOW

    elif column in [
        "branch_formulary",
        "assortment_qty_base_stock",
        "assortment_by",
        "assortment_start",
        "assortment_end",
    ]:
        color = PEACH

    elif column in [
        "tma_qty",
        "tma_start",
        "tma_end",
    ]:
        color = LIGHT_BLUE

    else:
        color = "F2F2F2"

    return PatternFill(
        start_color=color,
        end_color=color,
        fill_type="solid"
    )

# =========================
# LOOP ALL BRANCHES
# =========================

for branch_name in branches:

    print(
        f"EXPORTING {branch_name}"
    )

    # =========================
    # EXCEL
    # =========================

    wb = Workbook(write_only=True)

    ws = wb.create_sheet(
        branch_name[:31]
    )

    # =========================
    # HEADER
    # =========================

    header_row = []

    for col in COLUMNS:

        cell = WriteOnlyCell(ws)

        cell.value = TITLES[col]

        cell.font = header_font

        cell.fill = get_fill(col)

        cell.border = border

        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True
        )

        header_row.append(cell)

    ws.append(header_row)

    # =========================
    # FETCH
    # =========================

    batch_size = 3000

    last_item_code = None

    total_rows = 0

    while True:

        print(
            f"QUERYING: {branch_name}"
        )

        query = (
            supabase
            .table("daily_order")
            .select(",".join(COLUMNS))
            .eq("branch", branch_name)
            .eq("run_date", run_date)
            .order("item_code")
            .limit(batch_size)
        )

        if last_item_code:
            query = query.gt(
                "item_code",
                last_item_code
            )

        response = query.execute()

        rows = response.data

        print(
            f"{branch_name} | "
            f"ROWS FOUND: {len(rows)}"
        )

        if not rows:
            break

        for row in rows:

            excel_row = []

            for col in COLUMNS:

                value = row.get(col, "")

                cell = WriteOnlyCell(ws)

                cell.value = value

                cell.border = border

                cell.alignment = Alignment(
                    horizontal="center",
                    vertical="center",
                    wrap_text=False
                )

                excel_row.append(cell)

            ws.append(excel_row)

        total_rows += len(rows)

        last_item_code = rows[-1]["item_code"]

        print(
            f"{branch_name} | "
            f"EXPORTED: {total_rows}"
        )

    print(
        f"{branch_name} | "
        f"FINAL TOTAL: {total_rows}"
    )

    # =========================
    # SAVE
    # =========================

    safe_branch = (
        branch_name
        .replace("/", "-")
        .replace("\\", "-")
    )

    local_file_name = (
        f"{safe_branch}.xlsx"
    )

    wb.save(local_file_name)

    wb.close()

    print("EXCEL GENERATED")

    # =========================
    # UPLOAD
    # =========================

    storage_path = (
        f"{run_date}/{safe_branch}.xlsx"
    )

    print("UPLOADING...")

    with open(local_file_name, "rb") as f:

        supabase.storage.from_(
            "history-exports"
        ).upload(
            path=storage_path,
            file=f,
            file_options={
                "content-type":
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "upsert": "true"
            }
        )

    print("UPLOAD FINISHED")

    supabase.table(
        "history_exports"
    ).upsert(
        {
            "run_date": run_date,
            "branch_name": branch_name,
            "storage_path": storage_path,
        },
        on_conflict="run_date,branch_name"
    ).execute()

    print(
        f"DONE {branch_name}"
    )

    print(
        f"PATH: {storage_path}"
    )

    try:

        os.remove(local_file_name)

    except Exception as e:

        print(
            f"DELETE FAILED: {e}"
        )
