#!/usr/bin/env python3
"""
Python equivalent of:
  public.update_final_reorder_batch(p_run_date date, p_after_item_code text, p_batch_size integer)

The allocation logic is intentionally kept very close to the SQL function:
- same batch item selection
- same blocked rows
- same A/B/C classification
- same proportional allocation
- same remainder phase 1
- same remainder phase 2
- same final text values

Connection:
  Fast full mode for large runs:

    python scripts/update_final_reorder_batch.py --db-password "YOUR_DB_PASSWORD"

  Or set SUPABASE_DB_PASSWORD once, then run:

    python scripts/update_final_reorder_batch.py

  Batch mode, matching the original function shape:

    python scripts/update_final_reorder_batch.py --batch-mode --batch-size 200

  Note: Supabase REST/API key mode is much slower and is not suitable for 900,000 rows
  when the target is five minutes or less.

Optional:
    --run-date 2026-06-25
    --after-item-code ITEM001
    --batch-size 200
"""

from __future__ import annotations

import argparse
import json
import os
import smtplib
import ssl
import time
import urllib.error
import urllib.request
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, ROUND_FLOOR, ROUND_HALF_UP, InvalidOperation, getcontext
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from socket import gaierror
from typing import Any
from urllib.parse import quote_plus, urlparse
from urllib.parse import urlencode

try:
    import psycopg
    from psycopg import errors
    from psycopg.rows import dict_row
except ImportError:
    psycopg = None
    errors = None
    dict_row = None


BIG_BRANCHES = {
    "AL AIN MAIN",
    "BAWADI",
    "HEKMAT",
    "NATIONAL",
    "NEW ALAIN",
    "RIYAD CITY",
    "ASHAREJ",
    "SAMA",
    "SOUQ EXTRA-DXB",
    "SZR PH.",
    "ZAKHER",
    "JIMI SQUARE - AIN",
}


SUPABASE_PROJECT_URL = "https://rzvxjkbraufqbfhvftcy.supabase.co"
SUPABASE_PROJECT_REF = urlparse(SUPABASE_PROJECT_URL).hostname.split(".")[0]
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_FUNCTION_SQL_PATH = SCRIPT_DIR / "generate_daily_order_base_batch.sql"
DEFAULT_SUPABASE_SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6dnhqa2JyYXVmcWJmaHZmdGN5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTI3MTIwMCwiZXhwIjoyMDg2ODQ3MjAwfQ.D1QxC_yshFdCbKPU5UmEFOM6hw3vdQRYO2_5_KatW6c"

EMAIL_SENDER = "inventory.ainpharmacy@gmail.com"
EMAIL_PASSWORD = "nhpd iley uozd dybl"
EMAIL_RECEIVER = "inventory.ainpharmacy@gmail.com"

ZERO = Decimal("0")
ONE = Decimal("1")
getcontext().prec = 50


def send_email(subject: str, body: str) -> None:
    try:
        msg = MIMEMultipart()
        msg["From"] = EMAIL_SENDER
        msg["To"] = EMAIL_RECEIVER
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        context = ssl.create_default_context()
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.ehlo()
            server.starttls(context=context)
            server.ehlo()
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.send_message(msg)

        print(f"Email sent: {subject}")

    except Exception as e:
        print(f"Email failed: {e}")


def norm_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip().lower()


class SupabaseRestClient:
    def __init__(self, project_url: str, api_key: str) -> None:
        self.base_url = project_url.rstrip("/") + "/rest/v1"
        self.api_key = api_key

    def request(
        self,
        method: str,
        path: str,
        params: list[tuple[str, str]] | dict[str, str] | None = None,
        body: dict[str, Any] | None = None,
        prefer: str | None = None,
    ) -> Any:
        query = ""
        if params:
            query = "?" + urlencode(params)

        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        headers = {
            "apikey": self.api_key,
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        if prefer:
            headers["Prefer"] = prefer

        req = urllib.request.Request(
            self.base_url + "/" + path + query,
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as response:
                response_body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Supabase REST error {exc.code}: {error_body}") from exc

        if not response_body:
            return None
        return json.loads(response_body)

    def select_all(
        self,
        table: str,
        params: list[tuple[str, str]],
        page_size: int = 1000,
    ) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        offset = 0
        while True:
            page_params = [*params, ("limit", str(page_size)), ("offset", str(offset))]
            page = self.request("GET", table, page_params)
            if not page:
                break
            rows.extend(page)
            if len(page) < page_size:
                break
            offset += page_size
        return rows


@dataclass(slots=True)
class Row:
    item_code: str
    branch: Any
    n_branch: str
    store_stock: Decimal
    demand: Decimal
    pkg: Decimal
    n_purch: str
    n_rq: str
    is_big: int
    total_demand: Decimal = ZERO
    alloc_case: str = ""
    rn: int = 0
    total_for_dist: Decimal = ZERO
    prop_alloc: Decimal = ZERO
    remainder: Decimal = ZERO
    cum_zero_pkg: Decimal = ZERO
    alloc_p1: Decimal = ZERO
    remainder2: Decimal = ZERO
    full_rounds: Decimal = ZERO
    base_partial: Decimal = ZERO
    sum_elig_pkg: Decimal = ZERO
    full_extra: Decimal = ZERO
    cap_excess: Decimal = ZERO
    alloc_after_fr: Decimal = ZERO
    adj_partial: Decimal = ZERO
    cum_partial_pkg: Decimal = ZERO


def dec(value: Any, default: Decimal = ZERO) -> Decimal:
    if value is None:
        return default
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return default


def floor_dec(value: Decimal) -> Decimal:
    return value.to_integral_value(rounding=ROUND_FLOOR)


def greatest(*values: Decimal) -> Decimal:
    return max(values)


def least(*values: Decimal) -> Decimal:
    return min(values)


def sql_bigint_text(value: Decimal) -> str:
    return str(int(value.quantize(ONE, rounding=ROUND_HALF_UP)))


def final_reorder_total_value(value: str) -> int:
    text = (value or "").strip()
    return int(text) if text.isdigit() else 0


def update_job_state(
    database_url: str,
    run_date: str,
    phase: str,
    batch_size: int,
    last_item_code: str = "",
    last_result: dict[str, Any] | None = None,
    totals_done: bool = False,
    reset_started: bool = False,
    conn: psycopg.Connection | None = None,
) -> None:
    if psycopg is None:
        return

    result_json = json.dumps(last_result) if last_result is not None else None
    if conn is not None:
        with conn.cursor() as cur:
            cur.execute(
                """
                insert into public.daily_order_job_state (
                  run_date,
                  phase,
                  last_item_code,
                  batch_size,
                  started_at,
                  updated_at,
                  last_result,
                  error_message,
                  error_code,
                  error_context,
                  error_at,
                  error_count,
                  totals_done
                )
                values (
                  %s,
                  %s,
                  %s,
                  %s,
                  now(),
                  now(),
                  %s::jsonb,
                  null,
                  null,
                  null,
                  null,
                  0,
                  %s
                )
                on conflict (run_date) do update set
                  phase = excluded.phase,
                  last_item_code = excluded.last_item_code,
                  batch_size = excluded.batch_size,
                  started_at = case
                    when %s then now()
                    else coalesce(public.daily_order_job_state.started_at, now())
                  end,
                  updated_at = now(),
                  last_result = excluded.last_result,
                  error_message = case
                    when %s then null
                    else public.daily_order_job_state.error_message
                  end,
                  error_code = case
                    when %s then null
                    else public.daily_order_job_state.error_code
                  end,
                  error_context = case
                    when %s then null
                    else public.daily_order_job_state.error_context
                  end,
                  error_at = case
                    when %s then null
                    else public.daily_order_job_state.error_at
                  end,
                  error_count = case
                    when %s then 0
                    else public.daily_order_job_state.error_count
                  end,
                  totals_done = excluded.totals_done
                """,
                (
                    run_date,
                    phase,
                    last_item_code or "",
                    batch_size,
                    result_json,
                    totals_done,
                    reset_started,
                    reset_started,
                    reset_started,
                    reset_started,
                    reset_started,
                    reset_started,
                ),
            )
        return

    with psycopg.connect(database_url, autocommit=True) as state_conn:
        update_job_state(
            database_url=database_url,
            run_date=run_date,
            phase=phase,
            batch_size=batch_size,
            last_item_code=last_item_code,
            last_result=last_result,
            totals_done=totals_done,
            reset_started=reset_started,
            conn=state_conn,
        )


def update_job_state_error(
    database_url: str,
    run_date: str,
    phase: str,
    batch_size: int,
    exc: Exception,
    conn: psycopg.Connection | None = None,
) -> None:
    if psycopg is None:
        return

    error_message = str(exc)
    error_code = exc.__class__.__name__
    error_context = repr(exc)
    if conn is not None:
        with conn.cursor() as cur:
            cur.execute(
                """
                insert into public.daily_order_job_state (
                  run_date,
                  phase,
                  last_item_code,
                  batch_size,
                  started_at,
                  updated_at,
                  error_message,
                  error_code,
                  error_context,
                  error_at,
                  error_count,
                  totals_done
                )
                values (
                  %s,
                  %s,
                  '',
                  %s,
                  now(),
                  now(),
                  %s,
                  %s,
                  %s,
                  now(),
                  1,
                  false
                )
                on conflict (run_date) do update set
                  phase = excluded.phase,
                  batch_size = excluded.batch_size,
                  updated_at = now(),
                  error_message = excluded.error_message,
                  error_code = excluded.error_code,
                  error_context = excluded.error_context,
                  error_at = now(),
                  error_count = public.daily_order_job_state.error_count + 1,
                  totals_done = false
                """,
                (run_date, phase, batch_size, error_message, error_code, error_context),
            )
        return

    with psycopg.connect(database_url, autocommit=True) as state_conn:
        update_job_state_error(
            database_url=database_url,
            run_date=run_date,
            phase=phase,
            batch_size=batch_size,
            exc=exc,
            conn=state_conn,
        )


def install_base_generation_function(conn: psycopg.Connection, sql_path: Path) -> None:
    if not sql_path.exists():
        raise SystemExit(f"Base generation SQL file not found: {sql_path}")

    sql = sql_path.read_text(encoding="utf-8-sig", errors="replace")
    with conn.cursor() as cur:
        cur.execute(sql)


def ensure_daily_order_conflict_index(conn: psycopg.Connection) -> None:
    with conn.cursor() as cur:
        cur.execute(
            """
            select 1
            from pg_indexes
            where schemaname = 'public'
              and tablename = 'daily_order'
              and indexdef ilike '%unique%'
              and indexdef ilike '%run_date%'
              and indexdef ilike '%branch%'
              and indexdef ilike '%item_code%'
            limit 1
            """
        )
        if cur.fetchone():
            return

        print(
            "Creating required unique index on daily_order(run_date, branch, item_code)...",
            flush=True,
        )
        cur.execute(
            """
            select run_date, branch, item_code, count(*)::bigint as duplicate_count
            from public.daily_order
            group by run_date, branch, item_code
            having count(*) > 1
            limit 1
            """
        )
        duplicate = cur.fetchone()
        if duplicate:
            run_date, branch, item_code, duplicate_count = duplicate
            raise SystemExit(
                "Cannot create the required unique index because daily_order "
                "already has duplicate rows for the conflict key.\n"
                f"Example duplicate: run_date={run_date}, branch={branch}, "
                f"item_code={item_code}, count={duplicate_count}.\n"
                "Remove or merge duplicate rows first, then run this script again."
            )

        try:
            cur.execute(
                """
                create unique index if not exists daily_order_run_branch_item_uidx
                on public.daily_order (run_date, branch, item_code)
                """
            )
        except Exception as exc:
            if errors is not None and isinstance(exc, errors.UniqueViolation):
                raise SystemExit(
                    "Cannot create the required unique index because daily_order "
                    "already has duplicate (run_date, branch, item_code) groups.\n"
                    "Remove or merge duplicate rows first, then run this script again."
                ) from exc
            raise


def analyze_base_source_tables(conn: psycopg.Connection) -> None:
    tables = [
        "public.item_report",
        "public.branches",
        "public.sales_last_45_days",
        "public.stk_statement_today",
        "public.sales_90_days",
        "public.stk_ledger",
        "public.stk_mismatch",
        "public.transfer",
        "public.branch_formulary",
        "public.assortment",
        "public.tma",
        "public.stk_statement",
        "public.max_adj",
        "public.mrn",
    ]

    with conn.cursor() as cur:
        for table in tables:
            try:
                cur.execute(f"analyze {table}")
            except Exception as exc:
                print(f"Skipping analyze for {table}: {exc}", flush=True)


def generate_daily_order_base_all(
    database_url: str,
    run_date: str,
    batch_size: int,
    install_function: bool = True,
    sql_path: Path = BASE_FUNCTION_SQL_PATH,
    update_state: bool = True,
) -> tuple[int, str | None, int]:
    if psycopg is None:
        raise SystemExit(
            "Missing dependency: psycopg. Install it with: pip install psycopg[binary]"
        )

    try:
        conn_ctx = psycopg.connect(database_url, autocommit=True)
    except Exception as exc:
        raise SystemExit(explain_connection_error(exc)) from exc

    total_processed = 0
    last_item_code: str | None = None
    batches = 0
    after_item_code = ""

    state_conn_ctx = psycopg.connect(database_url, autocommit=True) if update_state else None

    with conn_ctx as conn:
        if state_conn_ctx is not None:
            state_conn_ctx.__enter__()
        try:
            with conn.cursor() as cur:
                cur.execute("set statement_timeout = 0")
                cur.execute("set synchronous_commit = off")
                cur.execute("set work_mem = '256MB'")

            if install_function:
                print("Installing/updating generate_daily_order_base_batch SQL function...", flush=True)
                install_base_generation_function(conn, sql_path)

            ensure_daily_order_conflict_index(conn)
            print("Analyzing base source tables...", flush=True)
            analyze_base_source_tables(conn)

            while True:
                batch_started_at = time.perf_counter()
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        select processed_count, last_item_code
                        from public.generate_daily_order_base_batch(%s, %s, %s)
                        """,
                        (run_date, after_item_code, max(batch_size, 1)),
                    )
                    processed_count, batch_last_item_code = cur.fetchone()

                processed_count = int(processed_count or 0)
                if processed_count <= 0:
                    break

                batches += 1
                total_processed += processed_count
                last_item_code = batch_last_item_code
                after_item_code = batch_last_item_code or ""
                if update_state:
                    update_job_state(
                        database_url=database_url,
                        run_date=run_date,
                        phase="base",
                        batch_size=batch_size,
                        last_item_code=after_item_code,
                        last_result={
                            "base_batches": batches,
                            "base_processed_items": total_processed,
                            "base_last_item_code": last_item_code,
                        },
                        totals_done=False,
                        conn=state_conn_ctx,
                    )
                print(
                    "base_generation "
                    f"batch={batches:,} processed_items={total_processed:,} "
                    f"last_item_code={last_item_code} "
                    f"seconds={time.perf_counter() - batch_started_at:.1f}",
                    flush=True,
                )

                if not batch_last_item_code:
                    break
        finally:
            if state_conn_ctx is not None:
                state_conn_ctx.__exit__(None, None, None)

    return total_processed, last_item_code, batches


def collect_item_batch(conn: psycopg.Connection, run_date: str, after_item_code: str, batch_size: int) -> list[str]:
    limit_size = max(batch_size, 1)
    with conn.cursor() as cur:
        cur.execute(
            """
            select distinct item_code
            from public.daily_order
            where run_date = %s
              and (%s = '' or item_code > %s)
            order by item_code
            limit %s
            """,
            (run_date, after_item_code, after_item_code, limit_size),
        )
        return [r[0] for r in cur.fetchall()]


def fetch_raw_rows(conn: psycopg.Connection, run_date: str, item_codes: list[str]) -> list[Row]:
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            """
            select
              o.item_code,
              o.branch,
              public._norm_text(o.branch) as n_branch,
              max(o.store_stock::numeric) over (partition by o.item_code) as store_stock,
              case
                when public._norm_text(o.reorder_qty) = 'non formulary'
                  or public._norm_text(o.item_purchase_type) in ('3#recalled','2#pr')
                then 0::numeric
                else greatest(coalesce(o.reorder_qty_num, 0), 0)::numeric
              end as demand,
              greatest(coalesce(o.item_minimum_order_unit, 1)::numeric, 1) as pkg,
              public._norm_text(o.item_purchase_type) as n_purch,
              public._norm_text(o.reorder_qty) as n_rq,
              case when upper(o.branch) = any(%s) then 1 else 2 end as is_big
            from public.daily_order o
            where o.run_date = %s
              and o.item_code = any(%s)
            """,
            (list(BIG_BRANCHES), run_date, item_codes),
        )
        rows = []
        for r in cur.fetchall():
            rows.append(
                Row(
                    item_code=r["item_code"],
                    branch=r["branch"],
                    n_branch=r["n_branch"],
                    store_stock=dec(r["store_stock"]),
                    demand=dec(r["demand"]),
                    pkg=greatest(dec(r["pkg"], ONE), ONE),
                    n_purch=r["n_purch"],
                    n_rq=r["n_rq"],
                    is_big=int(r["is_big"]),
                )
            )
        return rows


def group_by_item(rows: list[Row]) -> dict[str, list[Row]]:
    grouped: dict[str, list[Row]] = defaultdict(list)
    for row in rows:
        grouped[row.item_code].append(row)
    return grouped


def classify_rows(grouped: dict[str, list[Row]]) -> None:
    for item_rows in grouped.values():
        total_demand = sum((r.demand for r in item_rows), ZERO)
        for row in item_rows:
            row.total_demand = total_demand
            if row.store_stock <= ZERO:
                row.alloc_case = "A"
            elif total_demand <= row.store_stock:
                row.alloc_case = "B"
            else:
                row.alloc_case = "C"

        sorted_for_c = sorted(item_rows, key=lambda r: (-r.demand, r.is_big, r.n_branch))
        for index, row in enumerate(sorted_for_c, start=1):
            row.rn = index


def allocate_ab(row: Row) -> str:
    if row.alloc_case == "A":
        if row.n_rq == "non formulary" or row.n_purch == "3#recalled":
            return "NON FORMULARY"
        if row.n_purch == "2#pr":
            return "NO ORDER.PR"
        return ""

    if row.alloc_case == "B":
        if row.n_rq == "non formulary" or row.n_purch == "3#recalled":
            return "NON FORMULARY"
        if row.n_purch == "2#pr":
            return "NO ORDER.PR"
        if row.demand <= ZERO:
            return ""
        allocated = floor_dec(row.demand / row.pkg) * row.pkg
        if allocated > ZERO:
            return sql_bigint_text(allocated)
        return ""

    raise ValueError(f"allocate_ab called with alloc_case={row.alloc_case!r}")


def allocate_case_c(item_rows: list[Row]) -> dict[tuple[str, str], str]:
    c_rows = [r for r in item_rows if r.alloc_case == "C"]
    total_for_dist = sum((r.demand if r.demand > ZERO else ZERO for r in c_rows), ZERO)

    for row in c_rows:
        row.total_for_dist = total_for_dist
        if row.n_rq == "non formulary" or row.n_purch == "3#recalled":
            row.prop_alloc = Decimal("-1")
        elif row.n_purch == "2#pr":
            row.prop_alloc = Decimal("-2")
        elif row.demand <= ZERO:
            row.prop_alloc = ZERO
        else:
            if total_for_dist == ZERO:
                row.prop_alloc = ZERO
            else:
                row.prop_alloc = floor_dec((row.store_stock * row.demand / total_for_dist) / row.pkg) * row.pkg

    prop_allocated = sum((greatest(row.prop_alloc, ZERO) for row in c_rows), ZERO)
    remainder = c_rows[0].store_stock - prop_allocated if c_rows else ZERO
    for row in c_rows:
        row.remainder = remainder

    cum_zero_pkg = ZERO
    for row in sorted(c_rows, key=lambda r: r.rn):
        if row.prop_alloc == ZERO and row.demand > ZERO:
            cum_zero_pkg += row.pkg
        row.cum_zero_pkg = cum_zero_pkg
        if row.prop_alloc == ZERO and row.demand > ZERO and row.cum_zero_pkg <= row.remainder:
            row.alloc_p1 = row.pkg
        else:
            row.alloc_p1 = row.prop_alloc

    p1_used = sum(
        (
            row.pkg
            if row.prop_alloc == ZERO and row.demand > ZERO and row.cum_zero_pkg <= row.remainder
            else ZERO
            for row in c_rows
        ),
        ZERO,
    )
    for row in c_rows:
        row.remainder2 = row.remainder - p1_used

    sum_elig_pkg = sum(
        (
            row.pkg
            if row.alloc_p1 >= ZERO and row.alloc_p1 < row.demand and row.demand > ZERO
            else ZERO
            for row in c_rows
        ),
        ZERO,
    )
    remainder2 = max((row.remainder2 for row in c_rows), default=ZERO)
    if sum_elig_pkg > ZERO:
        full_rounds = floor_dec(remainder2 / sum_elig_pkg)
        base_partial = remainder2 - floor_dec(remainder2 / sum_elig_pkg) * sum_elig_pkg
    else:
        full_rounds = ZERO
        base_partial = remainder2

    for row in c_rows:
        row.sum_elig_pkg = sum_elig_pkg
        row.full_rounds = full_rounds
        row.base_partial = base_partial
        if row.alloc_p1 >= ZERO and row.demand > ZERO and row.alloc_p1 < row.demand:
            row.full_extra = least(full_rounds * row.pkg, row.demand - row.alloc_p1)
            row.cap_excess = greatest(full_rounds * row.pkg - (row.demand - row.alloc_p1), ZERO)
        else:
            row.full_extra = ZERO
            row.cap_excess = ZERO

    adj_partial = base_partial + sum((row.cap_excess for row in c_rows), ZERO)
    for row in c_rows:
        row.alloc_after_fr = row.alloc_p1 + row.full_extra
        row.adj_partial = adj_partial

    cum_partial_pkg = ZERO
    for row in sorted(c_rows, key=lambda r: r.rn):
        if row.alloc_after_fr >= ZERO and row.alloc_after_fr < row.demand and row.demand > ZERO:
            cum_partial_pkg += row.pkg
        row.cum_partial_pkg = cum_partial_pkg

    result: dict[tuple[str, str], str] = {}
    for row in c_rows:
        if row.prop_alloc == Decimal("-1"):
            val = "NON FORMULARY"
        elif row.prop_alloc == Decimal("-2"):
            val = "NO ORDER.PR"
        elif row.demand <= ZERO:
            val = ""
        else:
            partial_extra = (
                row.pkg
                if row.alloc_after_fr >= ZERO
                and row.alloc_after_fr < row.demand
                and row.cum_partial_pkg <= row.adj_partial
                else ZERO
            )
            final_num = greatest(row.alloc_after_fr + partial_extra, ZERO)
            if final_num > ZERO:
                val = sql_bigint_text(least(row.alloc_after_fr + partial_extra, row.demand))
            else:
                val = ""
        result[(row.item_code, row.n_branch)] = val

    return result


def build_allocations(rows: list[Row]) -> dict[tuple[str, str], str]:
    grouped = group_by_item(rows)
    classify_rows(grouped)

    result: dict[tuple[str, str], str] = {}
    for item_rows in grouped.values():
        for row in item_rows:
            if row.alloc_case in ("A", "B"):
                result[(row.item_code, row.n_branch)] = allocate_ab(row)
        if any(row.alloc_case == "C" for row in item_rows):
            result.update(allocate_case_c(item_rows))
    return result


def update_allocations(conn: psycopg.Connection, run_date: str, allocations: dict[tuple[str, str], str]) -> None:
    if not allocations:
        return

    payload = [(item_code, n_branch, val) for (item_code, n_branch), val in allocations.items()]
    with conn.cursor() as cur:
        with cur.copy(
            "copy temp_final_reorder_update (item_code, n_branch, val) from stdin"
        ) as copy:
            for row in payload:
                copy.write_row(row)

        cur.execute(
            """
            with totals as (
              select
                item_code,
                sum(
                  case
                    when btrim(coalesce(val, '')) ~ '^[0-9]+$'
                    then btrim(val)::bigint
                    else 0
                  end
                ) as total_reorder_today
              from temp_final_reorder_update
              group by item_code
            )
            update public.daily_order o
               set final_reorder_qty_store_stock_gt_0 = u.val,
                   total_final_reorder_today = case
                     when btrim(coalesce(u.val, '')) ~ '^[0-9]+$'
                     then btrim(u.val)::bigint
                     else 0
                   end,
                   total_reorder_today = t.total_reorder_today
            from temp_final_reorder_update u
            join totals t using (item_code)
            where o.run_date = %s
              and o.item_code = u.item_code
              and public._norm_text(o.branch) = u.n_branch
            """,
            (run_date,),
        )


def count_processed(conn: psycopg.Connection, run_date: str, item_codes: list[str]) -> int:
    with conn.cursor() as cur:
        cur.execute(
            """
            select count(distinct item_code)
            from public.daily_order
            where run_date = %s
              and item_code = any(%s)
            """,
            (run_date, item_codes),
        )
        return int(cur.fetchone()[0])


def stream_allocation_payload(
    conn: psycopg.Connection,
    run_date: str,
    fetch_size: int,
) -> tuple[list[tuple[str, str, str]], int, str | None, int]:
    query = """
        select
          o.item_code,
          public._norm_text(o.branch) as n_branch,
          max(o.store_stock::numeric) over (partition by o.item_code) as store_stock,
          case
            when public._norm_text(o.reorder_qty) = 'non formulary'
              or public._norm_text(o.item_purchase_type) in ('3#recalled','2#pr')
            then 0::numeric
            else greatest(coalesce(o.reorder_qty_num, 0), 0)::numeric
          end as demand,
          greatest(coalesce(o.item_minimum_order_unit, 1)::numeric, 1) as pkg,
          public._norm_text(o.item_purchase_type) as n_purch,
          public._norm_text(o.reorder_qty) as n_rq,
          case when upper(o.branch) = any(%s) then 1 else 2 end as is_big
        from public.daily_order o
        where o.run_date = %s
        order by o.item_code
    """

    payload: list[tuple[str, str, str]] = []
    current_item_code: str | None = None
    current_rows: list[Row] = []
    processed = 0
    rows_read = 0
    last_item_code: str | None = None

    def flush_current_item() -> None:
        nonlocal processed, last_item_code, current_rows, current_item_code
        if not current_rows or current_item_code is None:
            return

        allocations = build_allocations(current_rows)
        for (item_code, n_branch), val in allocations.items():
            payload.append((item_code, n_branch, val))

        processed += 1
        last_item_code = current_item_code
        if processed % 1000 == 0:
            print(
                f"processed_items={processed:,} rows_read={rows_read:,} update_rows={len(payload):,}",
                flush=True,
            )

        current_rows = []
        current_item_code = None

    with conn.cursor(name="final_reorder_raw_rows", row_factory=dict_row) as cur:
        cur.itersize = max(fetch_size, 1000)
        cur.execute(query, (list(BIG_BRANCHES), run_date))

        while True:
            batch = cur.fetchmany(max(fetch_size, 1000))
            if not batch:
                break

            for r in batch:
                row = Row(
                    item_code=r["item_code"],
                    branch=None,
                    n_branch=r["n_branch"],
                    store_stock=dec(r["store_stock"]),
                    demand=dec(r["demand"]),
                    pkg=greatest(dec(r["pkg"], ONE), ONE),
                    n_purch=r["n_purch"],
                    n_rq=r["n_rq"],
                    is_big=int(r["is_big"]),
                )
                rows_read += 1

                if current_item_code is None:
                    current_item_code = row.item_code
                elif row.item_code != current_item_code:
                    flush_current_item()
                    current_item_code = row.item_code

                current_rows.append(row)

    flush_current_item()
    return payload, processed, last_item_code, rows_read


def bulk_update_allocations(
    conn: psycopg.Connection,
    run_date: str,
    payload: list[tuple[str, str, str]],
) -> int:
    if not payload:
        return 0

    with conn.cursor() as cur:
        cur.execute(
            """
            create temp table temp_final_reorder_update (
              item_code text not null,
              n_branch text not null,
              val text
            ) on commit drop
            """
        )

        with cur.copy(
            "copy temp_final_reorder_update (item_code, n_branch, val) from stdin"
        ) as copy:
            for row in payload:
                copy.write_row(row)

        cur.execute(
            """
            create index temp_final_reorder_update_idx
            on temp_final_reorder_update (item_code, n_branch)
            """
        )
        cur.execute("analyze temp_final_reorder_update")

        cur.execute(
            """
            with totals as (
              select
                item_code,
                sum(
                  case
                    when btrim(coalesce(val, '')) ~ '^[0-9]+$'
                    then btrim(val)::bigint
                    else 0
                  end
                ) as total_reorder_today
              from temp_final_reorder_update
              group by item_code
            )
            update public.daily_order o
               set final_reorder_qty_store_stock_gt_0 = u.val,
                   total_final_reorder_today = case
                     when btrim(coalesce(u.val, '')) ~ '^[0-9]+$'
                     then btrim(u.val)::bigint
                     else 0
                   end,
                   total_reorder_today = t.total_reorder_today
            from temp_final_reorder_update u
            join totals t using (item_code)
            where o.run_date = %s
              and o.item_code = u.item_code
              and public._norm_text(o.branch) = u.n_branch
            """,
            (run_date,),
        )
        return cur.rowcount


def update_final_reorder_full_fast(
    database_url: str,
    run_date: str,
    fetch_size: int = 50000,
) -> tuple[int, str | None, int, int]:
    if psycopg is None:
        raise SystemExit(
            "Missing dependency: psycopg. Install it with: pip install psycopg[binary]"
        )

    try:
        conn_ctx = psycopg.connect(database_url)
    except Exception as exc:
        raise SystemExit(explain_connection_error(exc)) from exc

    with conn_ctx as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute("set local statement_timeout = 0")
                cur.execute("set local synchronous_commit = off")
                cur.execute("set local work_mem = '256MB'")

            payload, processed, last_item_code, rows_read = stream_allocation_payload(
                conn=conn,
                run_date=run_date,
                fetch_size=fetch_size,
            )
            updated_rows = bulk_update_allocations(conn, run_date, payload)

    return processed, last_item_code, rows_read, updated_rows


def collect_item_batch_rest(
    client: SupabaseRestClient,
    run_date: str,
    after_item_code: str,
    batch_size: int,
) -> list[str]:
    limit_size = max(batch_size, 1)
    params: list[tuple[str, str]] = [
        ("select", "item_code"),
        ("run_date", f"eq.{run_date}"),
        ("order", "item_code.asc"),
    ]
    if after_item_code != "":
        params.append(("item_code", f"gt.{after_item_code}"))

    item_codes: list[str] = []
    seen: set[str] = set()
    offset = 0
    page_size = 1000
    while len(item_codes) < limit_size:
        page_params = [*params, ("limit", str(page_size)), ("offset", str(offset))]
        page = client.request("GET", "daily_order", page_params)
        if not page:
            break
        for row in page:
            item_code = row.get("item_code")
            if item_code is None or item_code in seen:
                continue
            seen.add(item_code)
            item_codes.append(item_code)
            if len(item_codes) >= limit_size:
                break
        if len(page) < page_size:
            break
        offset += page_size

    return item_codes


def fetch_raw_rows_rest(
    client: SupabaseRestClient,
    run_date: str,
    item_codes: list[str],
) -> list[Row]:
    if not item_codes:
        return []

    selected_codes = set(item_codes)
    params: list[tuple[str, str]] = [
        (
            "select",
            "item_code,branch,store_stock,reorder_qty,reorder_qty_num,item_minimum_order_unit,item_purchase_type",
        ),
        ("run_date", f"eq.{run_date}"),
        ("item_code", f"gte.{item_codes[0]}"),
        ("item_code", f"lte.{item_codes[-1]}"),
        ("order", "item_code.asc"),
    ]
    raw_rows = [
        row
        for row in client.select_all("daily_order", params)
        if row.get("item_code") in selected_codes
    ]

    max_store_stock_by_item: dict[str, Decimal] = {}
    for row in raw_rows:
        item_code = row["item_code"]
        store_stock = dec(row.get("store_stock"))
        if item_code not in max_store_stock_by_item:
            max_store_stock_by_item[item_code] = store_stock
        else:
            max_store_stock_by_item[item_code] = max(max_store_stock_by_item[item_code], store_stock)

    rows: list[Row] = []
    for row in raw_rows:
        item_code = row["item_code"]
        n_rq = norm_text(row.get("reorder_qty"))
        n_purch = norm_text(row.get("item_purchase_type"))
        if n_rq == "non formulary" or n_purch in ("3#recalled", "2#pr"):
            demand = ZERO
        else:
            demand = greatest(dec(row.get("reorder_qty_num")), ZERO)

        branch = row.get("branch")
        branch_upper = "" if branch is None else str(branch).upper()
        rows.append(
            Row(
                item_code=item_code,
                branch=branch,
                n_branch=norm_text(branch),
                store_stock=max_store_stock_by_item[item_code],
                demand=demand,
                pkg=greatest(dec(row.get("item_minimum_order_unit"), ONE), ONE),
                n_purch=n_purch,
                n_rq=n_rq,
                is_big=1 if branch_upper in BIG_BRANCHES else 2,
            )
        )

    return rows


def update_allocations_rest(
    client: SupabaseRestClient,
    run_date: str,
    rows: list[Row],
    allocations: dict[tuple[str, str], str],
) -> None:
    totals_by_item: dict[str, int] = defaultdict(int)
    for (item_code, _n_branch), val in allocations.items():
        totals_by_item[item_code] += final_reorder_total_value(val)

    updated: set[tuple[str, Any, str]] = set()
    for row in rows:
        key = (row.item_code, row.n_branch)
        if key not in allocations:
            continue

        val = allocations[key]
        update_key = (row.item_code, row.branch, val)
        if update_key in updated:
            continue
        updated.add(update_key)

        params: list[tuple[str, str]] = [
            ("run_date", f"eq.{run_date}"),
            ("item_code", f"eq.{row.item_code}"),
        ]
        if row.branch is None:
            params.append(("branch", "is.null"))
        else:
            params.append(("branch", f"eq.{row.branch}"))

        client.request(
            "PATCH",
            "daily_order",
            params=params,
            body={
                "final_reorder_qty_store_stock_gt_0": val,
                "total_final_reorder_today": final_reorder_total_value(val),
                "total_reorder_today": totals_by_item[row.item_code],
            },
            prefer="return=minimal",
        )


def update_final_reorder_batch_rest(
    api_key: str,
    run_date: str,
    after_item_code: str = "",
    batch_size: int = 200,
) -> tuple[int, str | None]:
    client = SupabaseRestClient(SUPABASE_PROJECT_URL, api_key)
    item_codes = collect_item_batch_rest(client, run_date, after_item_code, batch_size)
    if not item_codes:
        return 0, None

    rows = fetch_raw_rows_rest(client, run_date, item_codes)
    allocations = build_allocations(rows)
    update_allocations_rest(client, run_date, rows, allocations)

    processed = len({row.item_code for row in rows if row.item_code in set(item_codes)})
    return processed, item_codes[-1]


def update_final_reorder_batch(
    database_url: str,
    run_date: str,
    after_item_code: str = "",
    batch_size: int = 200,
) -> tuple[int, str | None]:
    if psycopg is None:
        raise SystemExit(
            "Missing dependency: psycopg. Install it with: pip install psycopg[binary]"
        )

    try:
        conn_ctx = psycopg.connect(database_url)
    except Exception as exc:
        raise SystemExit(explain_connection_error(exc)) from exc

    with conn_ctx as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute("set local statement_timeout = 0")
                cur.execute(
                    """
                    create temp table temp_final_reorder_update (
                      item_code text not null,
                      n_branch text not null,
                      val text
                    ) on commit drop
                    """
                )

            item_codes = collect_item_batch(conn, run_date, after_item_code, batch_size)
            if not item_codes:
                return 0, None

            rows = fetch_raw_rows(conn, run_date, item_codes)
            allocations = build_allocations(rows)
            update_allocations(conn, run_date, allocations)

            processed = count_processed(conn, run_date, item_codes)
            return processed, item_codes[-1]


def build_database_url(args: argparse.Namespace) -> str:
    database_url = args.database_url or os.environ.get("DATABASE_URL", "")
    if database_url:
        return database_url

    password = args.db_password or os.environ.get("SUPABASE_DB_PASSWORD", "")
    if not password:
        raise SystemExit(
            "Supabase project URL is already in the code, but Postgres still needs the database password.\n"
            "The Supabase service_role API key cannot replace the Postgres password for this script.\n"
            "Run like this:\n"
            "  python update_final_reorder_batch.py --db-password \"YOUR_DB_PASSWORD\"\n"
            "or set:\n"
            "  $env:SUPABASE_DB_PASSWORD=\"YOUR_DB_PASSWORD\""
        )

    encoded_password = quote_plus(password)
    if args.db_host:
        if args.db_host.strip().upper() in {"POOLER_HOST", "POOLER_HOST_HERE"}:
            raise SystemExit(
                "POOLER_HOST_HERE is only an example placeholder, not a real server.\n"
                "Open Supabase Dashboard > Connect > Pooler and copy the real host.\n"
                "It usually looks like: aws-0-REGION.pooler.supabase.com"
            )
        if "://" in args.db_host:
            host_url = urlparse(args.db_host)
            raise SystemExit(
                f"--db-host must be a Postgres host only, without https://.\n"
                f"You entered: {args.db_host}\n\n"
                f"{host_url.hostname or args.db_host} is the Supabase API/project URL, not the database pooler host.\n"
                "Open Supabase Dashboard > Connect > Pooler and copy the Host value.\n"
                "It usually looks like: aws-0-REGION.pooler.supabase.com"
            )
        user = quote_plus(args.db_user)
        dbname = quote_plus(args.db_name)
        return (
            f"postgresql://{user}:{encoded_password}"
            f"@{args.db_host}:{args.db_port}/{dbname}?sslmode={args.sslmode}"
        )

    return (
        f"postgresql://postgres:{encoded_password}"
        f"@db.{SUPABASE_PROJECT_REF}.supabase.co:5432/postgres"
    )


def explain_connection_error(exc: Exception) -> str:
    text = str(exc)
    if "getaddrinfo failed" in text or isinstance(exc, gaierror):
        return (
            f"{text}\n\n"
            "Could not resolve the direct Supabase database host. This often happens because\n"
            f"db.{SUPABASE_PROJECT_REF}.supabase.co resolves to IPv6 only on some networks.\n"
            "Use the Supabase Pooler connection details from Dashboard > Connect > Pooler, for example:\n"
            "  python update_final_reorder_batch.py --db-password \"PASSWORD\" "
            "--db-host \"POOLER_HOST\" --db-user \"postgres.PROJECT_REF\" --db-port 6543\n"
            "Or paste the full pooler connection string with --database-url."
        )
    return text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--run-date",
        default="",
        help="Run date. Defaults to current local date + 1 day.",
    )
    parser.add_argument("--after-item-code", default="")
    parser.add_argument("--batch-size", type=int, default=200)
    parser.add_argument(
        "--batch-mode",
        action="store_true",
        help="Use the old batch behavior instead of processing the full run_date in one fast pass.",
    )
    parser.add_argument(
        "--skip-base",
        action="store_true",
        help="Skip generate_daily_order_base_batch and run final reorder only.",
    )
    parser.add_argument(
        "--base-batch-size",
        type=int,
        default=20000,
        help="Item batch size for generate_daily_order_base_batch before final reorder.",
    )
    parser.add_argument(
        "--skip-install-base-function",
        action="store_true",
        help="Do not install/update generate_daily_order_base_batch from the local SQL file before running it.",
    )
    parser.add_argument(
        "--base-function-sql",
        default=str(BASE_FUNCTION_SQL_PATH),
        help="Path to the SQL file containing public.generate_daily_order_base_batch.",
    )
    parser.add_argument(
        "--fetch-size",
        type=int,
        default=50000,
        help="Number of raw rows fetched from Postgres per streaming batch in fast full mode.",
    )
    parser.add_argument(
        "--rest",
        action="store_true",
        help="Force slow Supabase REST mode. Not recommended for large runs.",
    )
    parser.add_argument(
        "--database-url",
        default="",
        help="Supabase Postgres connection string. Defaults to DATABASE_URL.",
    )
    parser.add_argument(
        "--db-password",
        default="",
        help="Supabase database password. Used with the project URL already stored in this script.",
    )
    parser.add_argument(
        "--db-host",
        default=os.environ.get("SUPABASE_DB_HOST", ""),
        help="Optional Postgres host. Use the Supabase Pooler host if direct db host fails.",
    )
    parser.add_argument(
        "--db-user",
        default=os.environ.get("SUPABASE_DB_USER", f"postgres.{SUPABASE_PROJECT_REF}"),
        help="Optional Postgres user. Pooler usually uses postgres.PROJECT_REF.",
    )
    parser.add_argument(
        "--db-port",
        default=os.environ.get("SUPABASE_DB_PORT", "6543"),
        help="Optional Postgres port. Pooler transaction mode is commonly 6543.",
    )
    parser.add_argument(
        "--db-name",
        default=os.environ.get("SUPABASE_DB_NAME", "postgres"),
        help="Optional Postgres database name.",
    )
    parser.add_argument(
        "--sslmode",
        default=os.environ.get("SUPABASE_DB_SSLMODE", "require"),
        help="Optional Postgres sslmode.",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("SUPABASE_SERVICE_ROLE_KEY", DEFAULT_SUPABASE_SERVICE_ROLE_KEY),
        help="Supabase service_role API key. Used through Supabase REST when no Postgres password is passed.",
    )
    args = parser.parse_args()

    run_date = args.run_date or (date.today() + timedelta(days=1)).isoformat()
    api_key = args.api_key or os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")

    send_email(
        "DAILY ORDER JOB STARTED",
        f"update_final_reorder_batch started.\nRun date: {run_date}",
    )

    has_postgres_connection = bool(
        args.database_url
        or args.db_password
        or os.environ.get("DATABASE_URL")
        or os.environ.get("SUPABASE_DB_PASSWORD")
    )

    if args.rest:
        if not args.skip_base:
            raise SystemExit(
                "REST mode cannot run generate_daily_order_base_batch with exact SQL logic.\n"
                "Use the Postgres pooler connection, or pass --skip-base to run final reorder only."
            )
        if not api_key:
            raise SystemExit("REST mode needs SUPABASE_SERVICE_ROLE_KEY or --api-key.")
        send_email(
            "DAILY ORDER FINAL STARTED",
            f"Final reorder phase started in REST mode.\nRun date: {run_date}",
        )
        processed, last_item_code = update_final_reorder_batch_rest(
            api_key=api_key,
            run_date=run_date,
            after_item_code=args.after_item_code,
            batch_size=args.batch_size,
        )
        result = {
            "processed": processed,
            "last_item_code": last_item_code,
            "run_date": run_date,
            "mode": "rest_batch",
        }
        print(result)
        send_email(
            "DAILY ORDER JOB COMPLETED",
            f"update_final_reorder_batch completed successfully.\nResult: {result}",
        )
        return

    if has_postgres_connection:
        database_url = build_database_url(args)
        base_result: dict[str, Any] | None = None
        current_phase = "base" if not args.skip_base else "final"
        try:
            if args.skip_base:
                send_email(
                    "DAILY ORDER BASE SKIPPED",
                    f"Base phase skipped.\nRun date: {run_date}",
                )
            else:
                send_email(
                    "DAILY ORDER BASE STARTED",
                    f"Base phase started.\nRun date: {run_date}",
                )

            update_job_state(
                database_url=database_url,
                run_date=run_date,
                phase=current_phase,
                batch_size=args.base_batch_size if not args.skip_base else args.batch_size,
                last_item_code="",
                last_result=None,
                totals_done=False,
                reset_started=True,
            )

            if not args.skip_base:
                with psycopg.connect(database_url, autocommit=True) as conn:
                    with conn.cursor() as cur:
                        cur.execute("TRUNCATE TABLE public.daily_order")
                base_processed, base_last_item_code, base_batches = generate_daily_order_base_all(
                    database_url=database_url,
                    run_date=run_date,
                    batch_size=args.base_batch_size,
                    install_function=not args.skip_install_base_function,
                    sql_path=Path(args.base_function_sql),
                )
                base_result = {
                    "base_processed_items": base_processed,
                    "base_last_item_code": base_last_item_code,
                    "base_batches": base_batches,
                }

            current_phase = "final"
            send_email(
                "DAILY ORDER FINAL STARTED",
                f"Final reorder phase started.\nRun date: {run_date}",
            )
            update_job_state(
                database_url=database_url,
                run_date=run_date,
                phase="final",
                batch_size=args.base_batch_size if not args.skip_base else args.batch_size,
                last_item_code="",
                last_result=base_result,
                totals_done=False,
            )

            if args.batch_mode or args.after_item_code:
                processed, last_item_code = update_final_reorder_batch(
                    database_url=database_url,
                    run_date=run_date,
                    after_item_code=args.after_item_code,
                    batch_size=args.batch_size,
                )
                result = {
                    **(base_result or {}),
                    "processed": processed,
                    "last_item_code": last_item_code,
                    "run_date": run_date,
                    "mode": "postgres_batch",
                }
                update_job_state(
                    database_url=database_url,
                    run_date=run_date,
                    phase="done",
                    batch_size=args.base_batch_size if not args.skip_base else args.batch_size,
                    last_item_code="",
                    last_result=result,
                    totals_done=True,
                )
                print(result)
                send_email(
                    "DAILY ORDER JOB COMPLETED",
                    f"update_final_reorder_batch completed successfully.\nResult: {result}",
                )
                return

            processed, last_item_code, rows_read, updated_rows = update_final_reorder_full_fast(
                database_url=database_url,
                run_date=run_date,
                fetch_size=args.fetch_size,
            )
            result = {
                **(base_result or {}),
                "processed": processed,
                "last_item_code": last_item_code,
                "run_date": run_date,
                "rows_read": rows_read,
                "updated_rows": updated_rows,
                "mode": "postgres_full_fast",
            }
            update_job_state(
                database_url=database_url,
                run_date=run_date,
                phase="done",
                batch_size=args.base_batch_size if not args.skip_base else args.batch_size,
                last_item_code="",
                last_result=result,
                totals_done=True,
            )
            print(result)
            send_email(
                "DAILY ORDER JOB COMPLETED",
                f"update_final_reorder_batch completed successfully.\nResult: {result}",
            )
            return
        except Exception as exc:
            update_job_state_error(
                database_url=database_url,
                run_date=run_date,
                phase=current_phase,
                batch_size=args.base_batch_size if current_phase == "base" else args.batch_size,
                exc=exc,
            )
            send_email(
                "DAILY ORDER JOB FAILED",
                f"update_final_reorder_batch failed during {current_phase} phase.\nError: {exc}",
            )
            raise

    raise SystemExit(
        "For 900,000 rows under 5 minutes, use Postgres direct connection.\n"
        "Pass --db-password or set SUPABASE_DB_PASSWORD. REST/API key mode is too slow for this size.\n"
        "Example:\n"
        "  python update_final_reorder_batch.py --db-password \"YOUR_DB_PASSWORD\""
    )


if __name__ == "__main__":
    main()
