from supabase import create_client

import os
import xlsxwriter

# =========================
# SUPABASE
# =========================

SUPABASE_URL = "https://rzvxjkbraufqbfhvftcy.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6dnhqa2JyYXVmcWJmaHZmdGN5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTI3MTIwMCwiZXhwIjoyMDg2ODQ3MjAwfQ.D1QxC_yshFdCbKPU5UmEFOM6hw3vdQRYO2_5_KatW6c"

supabase = create_client(
    SUPABASE_URL,
    SUPABASE_KEY
)

# =========================
# TITLES
# =========================

TITLES = {
    'branch': 'BRANCH',
    'item_code': 'ITEM CODE',
    'item_name': 'ITEM NAME',
    'goods_received_last_7_days':
        'GOODS RECEIVED\nOF LAST 7 DAYS',

    'branch_stock': 'Branch Stock',
    'mismatch_stock': 'MISMATCH\nSTOCK',
    'store_stock': 'STORE STOCK',
    'pending_stock_received':
        'PENDING\nSTOCK\nRECEIVED',

    'extra_qty_more_than_month':
        'Extra QTY\n(More Than Month)',

    'max_adjustment_30d':
        'MAX\nADJUSTMENT\n(30 DAYS\nDEMAND BY\nBRANCH)',

    'reason':
        'REASON FOR MAX\nADJUSTMENT (30\nDAYS DEMAND BY\nBRANCH)',

    'demand_for_30_days':
        'DEMAND FOR\n30 DAYS',

    'reorder_point_min':
        'REORDER\nPOINT (MIN)',

    'reorder_max':
        'REORDER\nMAX',

    'reorder_qty':
        'REORDER QTY',

    'final_reorder_qty_store_stock_gt_0':
        'Final Re Order QTY\n(Store Stock >0)',

    'date_of_last_qty_received_in_branch':
        'DATE OF LAST QTY\nRECEIVED IN BRANCH',

    'qty_30_days_from_last_45d':
        '30 Days QTY (From\nLast 45 D)',

    'total_sold_qty_cash_last_90':
        'Total Sold Qty Cash\n(Last 90)',

    'total_sold_qty_online_last_90':
        'Total Sold Qty Online\n(Last 90)',

    'total_sold_qty_insurance_last_90':
        'Total Sold Qty Insurance\n(Last 90)',

    'total_sales_last_90_days':
        'Total Sales\nLast 90 Days',
    'branch_formulary':
        'Branch Formulary',

    'assortment_qty_base_stock':
        'Assortment Qty /\nBase Stock',

    'assortment_by':
        'Assortment By',

    'assortment_start':
        'Assortment Start',

    'assortment_end':
        'Assortment End',

    'tma_qty':
        'TMA Qty',

    'tma_start':
        'TMA Start',

    'tma_end':
        'TMA End',

    'item_purchase_type':
        'Item purchase type\n(item status)',

    'sales_orientation':
        'SALES\nORIANTATION',

    'category':
        'CATEGORY',

    'sub_category':
        'Sub-Category',

    'company':
        'Company',

    'supplier':
        'SUPPLIER',

    'indication':
        'Indication',

    'active_ingredient':
        'ACTIVE INGREDIANT',

    'pack_size':
        'Pack Size',

    'concentration':
        'Concentration',

    'product_type_form':
        'Product Type/Form',

    'retail_price':
        'RETAIL PRICE',

    'vat':
        'VAT',

    'is_upp':
        'IS UPP',

    'item_minimum_order_unit':
        'ITEM MINIMUM\nORDER UNIT',

    'barcode':
        'BARCODE',

    'store_item_classifications':
        'STORE ITEM\nCLASSIFICATIONS',
}

# =========================
# COLUMNS
# =========================

COLUMNS = list(TITLES.keys())

# =========================
# GET JOB
# =========================

job = (
    supabase
    .table("daily_order_exports")
    .select("*")
    .eq("status", "pending")
    .limit(1)
    .execute()
)

if not job.data:
    print("NO PENDING EXPORTS")
    exit()

export_job = job.data[0]

run_date = export_job["run_date"]
job_id = export_job["id"]

print(f"START EXPORT: {run_date}")

# =========================
# MARK PROCESSING
# =========================

supabase.table("daily_order_exports").update({
    "status": "processing"
}).eq("id", job_id).execute()

# =========================
# EXCEL
# =========================

file_name = f"daily_order_{run_date}.xlsx"

workbook = xlsxwriter.Workbook(
    file_name,
    {
        "constant_memory": True,
        "strings_to_urls": False,
        "nan_inf_to_errors": True,
    },
)

ws = workbook.add_worksheet("Branches Demand")

# =========================
# COLORS
# =========================

GREEN = "C6E0B4"
BLUE = "BDD7EE"
YELLOW = "FFE699"
PEACH = "F8CBAD"
LIGHT_BLUE = "B4C6E7"

# =========================
# GROUP COLORS
# =========================

def get_color(column):

    if column in [
        'branch',
        'item_code',
        'item_name',
    ]:
        color = GREEN

    elif column in [
        'branch_stock',
        'mismatch_stock',
        'store_stock',
        'pending_stock_received',
        'extra_qty_more_than_month',
    ]:
        color = BLUE

    elif column in [
        'max_adjustment_30d',
        'reason',
        'demand_for_30_days',
        'reorder_point_min',
        'reorder_max',
        'reorder_qty',
        'final_reorder_qty_store_stock_gt_0',
    ]:
        color = YELLOW

    elif column in [
        'branch_formulary',
        'assortment_qty_base_stock',
        'assortment_by',
        'assortment_start',
        'assortment_end',
    ]:
        color = PEACH

    elif column in [
        'tma_qty',
        'tma_start',
        'tma_end',
    ]:
        color = LIGHT_BLUE

    else:
        color = "F2F2F2"

    return color


def clean_excel_value(value):
    if value is None:
        return ""

    if isinstance(value, (list, dict)):
        return str(value)

    return value

# =========================
# HEADER
# =========================

header_formats = {
    col: workbook.add_format(
        {
            "bold": True,
            "font_size": 10,
            "font_color": "000000",
            "bg_color": get_color(col),
            "border": 1,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
        }
    )
    for col in COLUMNS
}

data_format = workbook.add_format(
    {
        "border": 1,
        "align": "center",
        "valign": "vcenter",
    }
)

ws.freeze_panes(1, 0)
ws.set_row(0, 48)

for col_index, col in enumerate(COLUMNS):
    ws.write(0, col_index, TITLES[col], header_formats[col])
    ws.set_column(col_index, col_index, 18, data_format)

# =========================
# FETCH
# =========================

batch_size = 50000

last_item_code = None

total_rows = 0
excel_row_index = 1

while True:

    query = (
        supabase
        .table("daily_order")
        .select(",".join(COLUMNS))
        .eq("run_date", run_date)
        .order("item_code")
        .limit(batch_size)
    )

    if last_item_code:
        query = query.gt(
            "item_code",
            last_item_code
        )

    response = query.execute()

    rows = response.data

    if not rows:
        break

    for row in rows:
        ws.write_row(
            excel_row_index,
            0,
            [
                clean_excel_value(row.get(col, ""))
                for col in COLUMNS
            ],
            data_format,
        )
        excel_row_index += 1

    total_rows += len(rows)

    last_item_code = rows[-1]["item_code"]

    print(f"EXPORTED: {total_rows}")

workbook.close()

if total_rows == 0:
    print(
        "WARNING: No daily_order rows were exported for "
        f"run_date={run_date}"
    )

print("EXCEL GENERATED")

try:
    import win32com.client as win32
except ModuleNotFoundError as exc:
    raise SystemExit(
        "pywin32 is required to convert XLSX to XLSB.\n"
        "Install it with: python -m pip install pywin32"
    ) from exc

print("CONVERTING TO XLSB...")

xlsx_path = os.path.abspath(file_name)

xlsb_file = f"daily_order_{run_date}.xlsb"
xlsb_path = os.path.abspath(xlsb_file)

excel = win32.DispatchEx("Excel.Application")

excel.Visible = False
excel.DisplayAlerts = False

try:
    workbook = excel.Workbooks.Open(xlsx_path)

    workbook.SaveAs(
        xlsb_path,
        FileFormat=50
    )

    workbook.Close(False)

finally:
    excel.Quit()

print("XLSB GENERATED")

# =========================
# UPLOAD
# =========================

print("UPLOADING...")

with open(xlsb_file, "rb") as f:

    supabase.storage.from_(
        "daily-order-exports"
    ).upload(
        path=xlsb_file,
        file=f,
        file_options={
            "content-type":
                "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
            "upsert": "true"
        }
    )

print("UPLOAD FINISHED")

# =========================
# UPDATE
# =========================

supabase.table("daily_order_exports").update({
    "status": "done",
    "storage_path": xlsb_file
}).eq("id", job_id).execute()

print("DONE")
try:
    os.remove(file_name)      # xlsx
except:
    pass

try:
    os.remove(xlsb_file)      # xlsb
except:
    pass
